<!DOCTYPE html>
<html>
   <head>
      <title>Coments-Success-pags</title>
      <link rel="stylesheet" type="text/css" href="Addhotel.css">
      <link href="https://fonts.googleapis.com/css?family=Catamaran|PT+Sans&display=swap" rel="stylesheet"> 
   </head>
   <body>
       <div class="[ Card ]" >
       <h1 class="[ Card-heding ]">Thank You</h1>
       <img class="[ Card-img ]" src="okey1.svg">
       <div class="[ card-test-holder ]">
       <div class="[ card-elemtner ]">
       <div class="[ card-text ]">
       <h2>We are grateful for your feedback</h2>
       we work daily to further develop our facilities and greatly appreciate your feedback. We all here at Holidaze Thansk you and still wish you a nice day </div>
       <a href="http://localhost:8081/ResultPage"> <button class="[ card-contet-2 ]" >
         <img class="[ left-button ]" src="Left.svg"  alt="img"><div class="[ text ]">Back to the Results</div>   
         </button>
      </a>
       </div>
    </div>
   </div>
</body>
</html>