<template>
    <div id="page-container">
    
        <footer class="[ footer ]">
            <div class="[ footer__holder ]">
                <ul class="[ footer__holder__button ]">
                    <h5 class="[ footer__holder__button-heding ]">Navigation</h5>
                    <img v-on:click="HomePage()" class="[ footer__holder__button-item ]"  src="../../../assets/Icons/Home.svg" alt="img" /> 
                    <img v-on:click="contactPage()" class="[ footer__holder__button-item ]" src="../../../assets/Icons/Contactus.svg" alt="img" />
                    <img  v-on:click="AdminPage()" class="[ footer__holder__button-item ]" src="../../../assets/Icons/Dashbord.svg" alt="img" />
                </ul>
                <ul class="[ footer__holder__contact ]">
                    <h5 class="[ footer__holder__contact-heding ]">Contact info</h5>
                    <li class="[ footer__holder__contcat-items ]">Adress: Buiksloterweg 55 </li>
                    <li class="[  footer__holder__contcat-items ]">Phone: 202-555-0126</li>
                    <li class="[  footer__holder__contcat-items ]">About Holidaze.no</li>
                </ul>
    
                <div class="[ footer__holder__map ]">
                    <h5 class="[ footer__holder__map-heding ]">Map</h5>
                    <div class="[ footer__holder__map-item ]"><iframe width="250" height="200" style="border-radius: 10px;" id="gmap_canvas"  src="https://maps.google.com/maps?q=%20Buiksloterweg%201031%20CD%20Amsterdam%20%20Buiksloterweg%201031%20CD%20Amsterdam%20&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe></div>
                </div>
            </div>
        </footer>
    </div>
</template>

<script>
export default {
    name: 'Fotter',

 methods: {
     HomePage: function() {
          this.$router.push({ name: 'LandingPage' });
     },
     AdminPage: function(){
          this.$router.push({ name: 'Adminpagelogin' });

     },
     contactPage: function(){
         this.$router.push({ name: 'ContatusPage' });
     }
      
 }


    
}
</script>

<style lang="scss" scoped>
/*
bg = Background color
*/

/*
el = Element color
D = Dark
L = light
nr =  who position the color palette has in the style guide ( page 3 styleguide pdf "Color-deagram") 
*/

/* Fonts Importet form google font */

@import url('https://fonts.googleapis.com/css?family=Catamaran|PT+Sans|Quicksand|Raleway');
$font-Raleway: 'Raleway',
sans-serif;
$font-Catamaran: 'Catamaran',
sans-serif;
$font-Pt_sans: 'PT Sans',
sans-serif;
$font-Quicksand: 'Quicksand',
sans-serif;
/*Color*/

/*------------------*/

$bg-Color: #ffffff;
/*Blue Pallete nr.1*/

$el-L-ExstraLiteblue: #D7E2ED;
$el-L-Liteblue: #B6DBF2;
$el-L-Blue: #79ACD9;
$el-D-LiteDarkBlue: #416A8E;
$el-D-Darkblue: #323640;
/*Green Palette nr.2*/

$el-L-Green: #82BFBF;
$el-D-Green: #5E8A8A;
$el-D-ExstraliteGray: #BBBFBF;
$el-D-LiteDarkGray: #707373;
$el-D-DarkGray: #404141;
/*White pallette nr.3*/

$el-L-White: #FBFBFB;
$el-L-White2: #F6F6F6;
$el-L-White3: #FAFAFA;
$el-L-White4: #F0F0F0;
/*Exstra Color nr.4*/

$ek-D-Red: #B92025;
$ek-D-Blue: #17273F;
$ek-D-Gray: #E8E8E8;


#page-container {
  position: relative;
  min-height: 80vh;
}

#content-wrap {
  padding-bottom: 2.5rem;    /* Footer height */
}


.footer {
    border-top: 5px solid $el-L-Green;
    background-color: $el-D-Darkblue;
position: absolute;
  bottom: 0;
  width: 100%;
  height: 400px;
    li{
        list-style-type: none;
    }
    &__holder {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            justify-items: center;
            justify-content: space-evenly;
            max-width: 1300px;
            margin:  auto;
     
        &__button {
            text-align: center;
            justify-content: center;
            &-item {
                display: inline-block;
                width: 70px;
                margin: 15px;
                color: #ffff;
                text-align: left;
            }
            &-heding {
                font-family: $font-Quicksand;
                font-weight: 700;
                text-align: center;
                border-bottom: $el-L-Green 5px solid;
                color: $el-L-White;
                font-size: 25px; 
            }
          
        }
      
        &__contact {
            display: inline-block;
            list-style-type: none;
            color: $el-L-White;
            
            text-align: center;
               width: 65%;
               text-align: justify;
                &-items {
                display: inline-block;
                width: 70px;
                margin: 15px;
               
                text-align: left;
            }
            
            &-heding {
                width: 100%;
                text-align: center;
                border-bottom: $el-L-Green 5px solid;
                color: $el-L-White;
                font-family: $font-Quicksand;
                font-weight: 700;
                font-size: 25px;
            }
        }
        &__map {
            display: inline-block;
            padding: 16px;
            filter: grayscale(20%);
            text-align: center;
            &-heding {
                font-family: $font-Quicksand;
                text-align: center;
                border-bottom: $el-L-Green 5px solid;
                color: $el-L-White;
                font-weight: 700;
                font-size: 25px;
            }
        }
    }
}

@media screen and (max-width: 950px) {
    .footer {
        position: absolute;
  right: 0;
  bottom: 0;
  left: 0;
  top: 50px;
  margin-top: 25px;
        &__holder {
            grid-template-columns: repeat(auto-fill, minmax(450px, 1fr));
            background-color: $el-D-Darkblue;
            &__button {
                display: block;
                text-align: center;
                margin: 0px auto;
                padding: 0px;
                  width: 30%;
            }
            &__contact {
                display: block;
                text-align: center;
                margin: 0px auto;
                padding: 0px;
                width: 30%;
            }
            &__map {
                text-align: center;
            }
        }
    }
}
</style>

