
<template>
    <div>
    
        <div class="[ E-holder ]">
    
            <input class="[ E-holder__input ]" v-model="surchFilter" type="text" placeholder="surch" >
            <button class="[ E-holder__Button ]">surch </button>
          
    
            <div class="[ E-holder__row ]">
                <div class="[ E-holder__row__button ]" type="button"></div>
                <p class="[ E-holder__row__button--text ]">heyehy</p>
                <div class="[ E-holder__row__button ]" type="button"></div>
                <p class="[ E-holder__row__button--text ]">heyehy</p>
                <div class="[ E-holder__row__button ]" type="button"></div>
                <p class="[ E-holder__row__button--text ]">heyehy</p>
    
    
    
            </div>
            <div class="[ E-holder__row ]">
                <div class="[ E-holder__row__button ]" type="button"></div>
                <p class="[ E-holder__row__button--text ]">heyehy</p>
    
                <div class="[ E-holder__row__button ]" type="button"></div>
                <p class="[ E-holder__row__button--text ]">heyehy</p>
    
                <div class="[ E-holder__row__button ]" type="button"></div>
                <p class="[ E-holder__row__button--text ]">heyehy</p>
            </div>
        
        </div>
    
    </div>
</template>

<script>
export default {
    name: 'Surch',
    data(){
      return{
        surchFilter:"",
        items: [],
      }
    },




    methods: {
        getitems: function() {
            fetch('establishments.json')
                .then((response) => {
                    return response.json()
                })
                .then((result) => {
                  /*   this.items = result; */
                    console.log(this.items)
                    this.items = data.cards.filter(card => card.establishmentName);
                })
                .catch(err => {
                    console.log(err);
                });
        },
    },



    computed: {
    filteritems() {
      return this.items.filter((items) => {
        return items.establishmentName.match(this.surchFilter)
    
      });
    },


  }


}

</script>

<style lang="scss" scoped>
/*
bg = Background color
*/

/*
el = Element color
D = Dark
L = light
nr =  who position the color palette has in the style guide ( page 3 styleguide pdf "Color-deagram") 
*/

/* Fonts Importet form google font */

@import url('https://fonts.googleapis.com/css?family=Catamaran|PT+Sans|Quicksand|Raleway');
$font-Raleway: 'Raleway',
sans-serif;
$font-Catamaran: 'Catamaran',
sans-serif;
$font-Pt_sans: 'PT Sans',
sans-serif;
$font-Quicksand: 'Quicksand',
sans-serif;
/*Color*/

/*------------------*/

$bg-Color: #ffffff;
/*Blue Pallete nr.1*/

$el-L-ExstraLiteblue: #D7E2ED;
$el-L-Liteblue: #B6DBF2;
$el-L-Blue: #79ACD9;
$el-D-LiteDarkBlue: #416A8E;
$el-D-Darkblue: #323640;
/*Green Palette nr.2*/

$el-L-Green: #82BFBF;
$el-D-Green: #5E8A8A;
$el-D-ExstraliteGray: #BBBFBF;
$el-D-LiteDarkGray: #707373;
$el-D-DarkGray: #404141;
/*White pallette nr.3*/

$el-L-White: #FBFBFB;
$el-L-White2: #F6F6F6;
$el-L-White3: #FAFAFA;
$el-L-White4: #F0F0F0;
/*Exstra Color nr.4*/

$ek-D-Red: #B92025;
$ek-D-Blue: #17273F;
$ek-D-Gray: #E8E8E8;
.E-holder {
    margin:  auto;
    margin-top: 55px;
    padding: 35px;
    max-width: 1100px;
    border-radius: 10px;
    background-color: $el-D-Darkblue;
    
   
    &__input {
        width: 100%;
        display: grid;
        grid-template-columns: 1fr 1fr;
        
        
        border-radius: 3px;
        height: 40px;  
        border: none;
        padding: 5px;
        font-size: 17px;
        justify-content: center;
       
    }
    &__row {
        display: grid;
         grid-template-columns: 1fr 1fr 1fr;
         grid-gap: 1px;
        text-align: center;
        padding: 15px;
        width: 700px;
        margin: auto;
        justify-items: center;
        &__button {
            border-radius: 90%;
            background-color: #5E8A8A;
            height: 56px;
            width: 56px;
             cursor: pointer;
        }
        &__button--text {
            color: #ffff;
            grid-row: 2/3;
            
            
        }
    }
    .E-holder__Button {

      display: block;
      margin: 30px auto;
       cursor: pointer;
     background-color: #416A8E;
      border-radius: 5px;
      color: $el-L-White;
      font-family: $font-Catamaran;
      font-style: bold;
       border: none;
      font-size: 17px;
      width: 15%;
      color: #ffff;
     
    }
}

/*needs som work */

@media screen and (max-width: 1200px) {
    .E-holder {
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        border-radius: 0px;
        height: 400px;
        &__input {
          border-radius: 5px;
          border: transparent;
            margin-bottom: 10px;
        }
        &__row {
            width: auto;
            margin: auto;
            
        }
    }

   

}
</style>
