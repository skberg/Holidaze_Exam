<template>
    <div>
        <div class="[ navbar ]">
        <router-link to="/">
            <div class="[ navbar__Hedicon ]">
                <img class="[ navbar__Hedicon-item1 ]" src="../../../assets/Icons/Nav-logo-v2.svg" alt="img" width="100"/>
             
            </div>
         </router-link>
    
            <div class="[ navbar__ul-cont ]">
                <ul class=" [ navbar__ul-cont__list ]">
    
                    <router-link to="/">
                        <li class="[ navbar__ul-cont__list-element ]">
                            <p>Home</p>
                        </li>
                    </router-link>
                    <router-link to="/ContatusPage">
                        <li class="[ navbar__ul-cont__list-element  ]">
                            <p>Contact Us</p>
                        </li>
                    </router-link>
                    <router-link to="/Adminpagelogin">
                        <li class="[ navbar__ul-cont__list-element  ]">
                            <p>Admin</p>
                        </li>
                    </router-link>
                </ul>
    
    
    
            </div>
        </div>
    
    
    
    
    
    
    
        <div id="mySidenav" class="[ sidenav ]">
            <a href="javascript:void(0)" class="[ closebtn ]" v-on:click="closeNav()"><img class="[ closebtn ]" src="../../../assets/Icons/sibarnicon.png"></a>
    
            <router-link to="/">
                <a><img class="[ sidnav-icons ]" src="../../../assets/Icons/Home.svg" alt="img"><p>Home</p></a>
            </router-link>
            <router-link to="/ContatusPage">
                <a><img class="[ sidnav-icons ]" src="../../../assets/Icons/Contactus.svg" alt="img"><p >Contact us</p></a>
            </router-link>
            <router-link to="/Adminpagelogin">
                <a><img class="[ sidnav-icons ]" src="../../../assets/Icons/Dashbord.svg" alt="img"><p>Admin</p></a>
            </router-link>
        </div>
    
    
    
    
    
    
        <span class="clicker" value="togglee" v-on:click="openNav(event)">
                
                      <div class="bar1"></div>
                      <div class="bar2"></div>
                      <div class="bar3"></div>
                </span>
    
    
    
    
    </div>
</template>

<script>
export default {
    name: 'Navbar',
    componets: {},

    data() {
        // declare message with an empty value
        return {
            event: '',
        }
    },

    methods: {

        openNav: function(event) {
            document.getElementById("mySidenav").style.width = "250px";

        },

        closeNav: function() {
            document.getElementById("mySidenav").style.width = "0";

        },



    }
}

</script>

<style lang="scss" scoped>
/*
bg = Background color
*/

/*
el = Element color
D = Dark
L = light
nr =  who position the color palette has in the style guide ( page 3 styleguide pdf "Color-deagram") 
*/

/* Fonts Importet form google font */

@import url('https://fonts.googleapis.com/css?family=Catamaran|PT+Sans|Quicksand|Raleway');
$font-Raleway: 'Raleway',
sans-serif;
$font-Catamaran: 'Catamaran',
sans-serif;
$font-Pt_sans: 'PT Sans',
sans-serif;
$font-Quicksand: 'Quicksand',
sans-serif;
/*Color*/

/*------------------*/

$bg-Color: #ffffff;
/*Blue Pallete nr.1*/

$el-L-ExstraLiteblue: #D7E2ED;
$el-L-Liteblue: #B6DBF2;
$el-L-Blue: #79ACD9;
$el-D-LiteDarkBlue: #416A8E;
$el-D-Darkblue: #323640;
/*Green Palette nr.2*/

$el-L-Green: #82BFBF;
$el-D-Green: #5E8A8A;
$el-D-ExstraliteGray: #BBBFBF;
$el-D-LiteDarkGray: #707373;
$el-D-DarkGray: #404141;
/*White pallette nr.3*/

$el-L-White: #FBFBFB;
$el-L-White2: #F6F6F6;
$el-L-White3: #FAFAFA;
$el-L-White4: #F0F0F0;
/*Exstra Color nr.4*/

$ek-D-Red: #B92025;
$ek-D-Blue: #17273F;
$ek-D-Gray: #E8E8E8;
body {
    padding: 0;
    margin: 0;
}

.navbar {
    display: inline-block;
    width: 100%;
    background-color: $el-L-White;
    padding-bottom: 25px;
    &__Hedicon {
        display: inline-block;
        padding-top: 10px;
     
        height: 100%;
        &-item1 {
            padding-top: 20px;
            padding-left: 10px;
            padding-right: 10px;
            height: 100%;
            
         
        }
      
    }
    &__ul-cont__list {
        display: inline-block;
        text-align: center;
        color: #000;
        top: 0;
        right: 0;
        left: 0;
        position: absolute;
        font-family: $font-Raleway;
        font-weight: 200;
        &-element {
            display: inline-block;
            text-align: center;
            text-decoration: none;
            color: $el-D-DarkGray;
            padding: 0px 50px 0px 10px;
            &::after {
                content: '';
                display: block;
                width: 0;
                height: 2px;
                background: $el-L-Green;
                transition: width .3s;
            }
            &:hover::after {
                width: 100%;
                /*  transition: width .3s; */
            }
        }
    }
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: $el-D-DarkGray;

    overflow-x: auto;
    transition: 0.5s;
    padding-top: 60px;
  
    .sidnav-icons {
        font-size: 35px;
        height: 80px;
        border-radius: 90%;
        padding-right: 2px;
    }
}

.sidenav a {
    top: 60px;
    position: relative;
    padding: 0px 0px 50px 40px;
    text-decoration: none;
    color: $el-D-ExstraliteGray;
    display: block;
}

.sidenav p {
    font-family: $font-Catamaran;
    font-size: 15px;
    font-weight: 1000;
    width: 48%;
    text-align: center;
    justify-content: center;
}

.sidenav a:hover {
    color: $el-L-White;
}

.sidenav .closebtn {
    position: absolute;
    top: 10px;
    right: 15px;
    width: 30px;
    ;
}

.clicker {
    font-size: 30px;
    cursor: pointer;
    right: 0;
    position: fixed;
    top: 0;
    padding-top: 15px;
    padding-right: 20px;
    display: none
}

.container {
    display: inline-block;
    cursor: pointer;
}

.bar1{
    width: 10px;
    height: 5px;
    background-color: $ek-D-Gray;
    margin: 5px 0;
    transition: 0.4s;
    border-radius: 5px;
}
.bar2{
    width: 25px;
    height: 5px;
    background-color: $el-L-Green;
    margin: 5px 0;
    transition: 0.4s;
    border-radius: 5px;
}
.bar3 {
    width: 35px;
    height: 5px;
    background-color: $ek-D-Gray;
    margin: 5px 0;
    transition: 0.4s;
    border-radius: 5px;
}






@media screen and (max-height: 450px) {
    .sidenav {
        padding-top: 15px;
    }
    .sidenav a {
        font-size: 18px;
    }
}

@media screen and (min-width: 0px) and (max-width: 1030px) {
    .clicker {
        display: block;
    }
    .navbar {
        &__Hedicon {
            text-align: center;
            &-item1 {
                display: block;
            }
            &-item2 {
                display: none;
            }
        }
        /* show it on small screens */
        &__ul-cont__list {
            display: none;
        }
    }
}

@media screen and (min-width: 1030px) and (max-width: 1224px) {
    .clicker {
        display: none;
    }
    /* hide it elsewhere */
}
</style>
