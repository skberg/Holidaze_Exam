<template>
    <div>
        <navbar></navbar>
    
    <p v-if="errors.length">
                        <p class="errorne" v-for="error in errors">{{ error }}</p>
                    </p>


        
        <div class="[ card-holder ]">

                

               
            <div class="[ card-holder__card ]" @submit="checkForm" >

           
                      
                <p v-if="errors.length">
                        <p class="error-to" v-for="error in errors">{{ error }}</p>
                    </p>

                <form class="[ card-holder__card__card-form ]" method="POST" action="http://192.168.64.2/Holidaze/server/contact-success.php">
    
                <label class="[ card-holder__card__card-form__label ]" for="clientName"><b>*</b>Name:</label>
                <input  class="[ card-holder__card__card-form__label-input ]"type="text" name="clientName" id="clientName" v-model="name" maxlength="25">
          

  
                <label class="[ card-holder__card__card-form__label ]"for="email"><b>*</b>E-mail:</label>
                <input class="[ card-holder__card__card-form__label-input  ]" type="text" name="email" id="email" v-model="mail" maxlength="25" >
   



                    <label class="[ card-holder__card__card-form__label  ]" for="message">Message:</label>
                    <textarea class="[ card-holder__card__card-form__label-Texteara ]" name="message" id="message" rows="6" cols="50" maxlength="150"></textarea>
                 
                    <input class="[ card-holder__card-SumitButton ]" v-on:keyup.enter="submit" type="submit"> 
                </form>
       
            </div>
       

            <div class="[ card-holder__border-Line ]"></div>
            <div class="[ card-holder__card ]">
                <div class="mapouter">
                    <div class="[ gmap_canvas ]"><iframe width="490" height="490" style="border-radius: 10px;" id="gmap_canvas"  src="https://maps.google.com/maps?q=%20Buiksloterweg%201031%20CD%20Amsterdam%20%20Buiksloterweg%201031%20CD%20Amsterdam%20&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe></div>
                </div>
            </div>
        </div>




       





 
    </div>
</template>

<script>
import Navbar from "../container/navbar/Navbar";
export default {
    name: "ContatusPage",

    components: {
        Navbar,
    },

    data() {
        return {
         
            errors:[],
            name:null,
            mail:null,
        
        }
    },

   methods: {
            checkForm:function(e) {
            
            if(this.name && this.mail) return true;
            this.errors = [];
        
            if(!this.name) this.errors.push("Name required ");
            if(!this.mail) this.errors.push("E-mail required ");
            
            e.preventDefault();
        }


        

    },

        keymonitor: function(event) {
        console.log(event.key);
       if(event.key == "Enter"){
         console.log('the id of the input was:' + event.currentTarget.id);
         console.log("enter key was pressed!");
       }
    }




}
</script>

<style lang="scss" scoped>
/*
bg = Background color
*/

/*
el = Element color
D = Dark
L = light
nr =  who position the color palette has in the style guide ( page 3 styleguide pdf "Color-deagram") 
*/

/* Fonts Importet form google font */

@import url('https://fonts.googleapis.com/css?family=Catamaran|PT+Sans|Quicksand|Raleway');
$font-Raleway: 'Raleway',
sans-serif;
$font-Catamaran: 'Catamaran',
sans-serif;
$font-Pt_sans: 'PT Sans',
sans-serif;
$font-Quicksand: 'Quicksand',
sans-serif;
/*Color*/

/*------------------*/

$bg-Color: #ffffff;
/*Blue Pallete nr.1*/

$el-L-ExstraLiteblue: #D7E2ED;
$el-L-Liteblue: #B6DBF2;
$el-L-Blue: #79ACD9;
$el-D-LiteDarkBlue: #416A8E;
$el-D-Darkblue: #323640;
/*Green Palette nr.2*/

$el-L-Green: #82BFBF;
$el-D-Green: #5E8A8A;
$el-D-ExstraliteGray: #BBBFBF;
$el-D-LiteDarkGray: #707373;
$el-D-DarkGray: #404141;
/*White pallette nr.3*/

$el-L-White: #FBFBFB;
$el-L-White2: #F6F6F6;
$el-L-White3: #FAFAFA;
$el-L-White4: #F0F0F0;
/*Exstra Color nr.4*/

$ek-D-Red: #B92025;
$ek-D-Blue: #17273F;
$ek-D-Gray: #E8E8E8;
body {
    background-color: $bg-Color;
    margin: 0 !important;
    padding: 0 !important;
}
      b{
        color: $ek-D-Red;
        padding: 5px;
        opacity: 0.8;
    }




.card-holder {
    display: grid;
    grid-template-columns: auto auto auto ;
    grid-gap: 20px;
    margin-left: auto;
    margin-right: auto;
    justify-content: center;
   
    &__card {
        background-color: $el-L-White;
        width: 490px;
        margin-top: 125px;
        height: 490px;
        border-radius: 10px;
     box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 29%);
     
        &__card-form {
           
           display: grid;
            grid-template-columns:  2fr;
            justify-content: center;
   
          
            &__label{
                    font-size: 1.1rem;
                font-family: $font-Catamaran;
                font-weight: 600;
            }
            b{
        color: $ek-D-Red;
        padding: 5px;
        opacity: 0.8;
    }
            &__label-input {
                margin-bottom: 55px;
                width: 400px;
                border: none;
                font-size: 1rem;
                border-bottom: $el-L-Green 2px solid;
                background-color: transparent;
                font-family: $font-Catamaran;

            }

            &__label{
                  font-family: $font-Catamaran;
                   b{
        color: $ek-D-Red;
        padding: 5px;
        opacity: 0.8;
    }
            }
            &__label-Texteara {
                background-color: $el-L-White2;
                border: 2px solid $el-L-Green;
                resize: none;
                width: 400px;
                padding: 10px;
                font-size: 1rem;
                border-radius: 3px;
                font-family: $font-Pt_sans;
            }
     
        }
         &-SumitButton {
             
                background-color: $el-D-LiteDarkBlue;
                border: none;
                width: 75%;
                margin: 53px auto;
             
           
             
           
                color: $el-L-White;
                border-radius:  5px  ;
                font-family: $font-Catamaran;
                font-weight: 700;
                font-size: 18px;
            }
    
    }
      &__border-Line {
            border-left: 5px solid $el-L-Green;
            height: 490px;
            margin-top: 125px;
         
            border-radius: 10px 10px 10px 10px;
        }
}









.errorne{
    background-color: $el-L-Green;
    color: $el-D-DarkGray;
    font-weight: 700;
    text-align: center;
border-radius: 10px;
    width: 400px;
height: 30px;
	margin: 1px auto;


}






.error-to{
    background-color: $el-L-Green;
    color: $el-D-DarkGray;
    font-weight: 700;
    text-align: center;
    margin: auto;
    width: auto;
	height: 50px;
	
	margin-top: -20px;
 
    margin-bottom: -20px;
    padding: 10px;
    border-radius: 10px 10px 0px 0px;
    animation: mymovee 0.5s ;
}


@keyframes mymovee {
  from {height: 0px;}
  to {height: 50px;}
}







/* laptop */

@media screen and (min-width: 100px) and (max-width: 10838px) {

    .card-holder {
    display: grid;
     margin-top: 30px; 
    &__card {
        
        width: 490px;
        height: 490px;
        &__card-form {
           
            justify-content: center;
            padding: 25px;
            justify-content: center;
        }
       
    }
    
}

.error-one{
    background-color: $el-L-Green;
    color: $el-D-DarkGray;
    font-weight: 700;
    text-align: center;
    margin: auto;
    width: 400px;
	height: 100px;
	position: absolute;
	top: -800px;
	bottom: 0;
	left: 10px;
	right: 550px;
	padding-top: 20px;
	margin: auto;
    z-index: -1;
    border-radius: 10px 10px 0px 0px;
    animation: mymove 0.5s ;
}


@keyframes mymove {
  from {height: 0px;}
  to {height: 100px;}
}      


.error-to{
    display: none;;
}
}































@media screen and (max-width: 1050px) {
    /*  responsiv */
    .card-holder {
        grid-template-columns: 1fr;
        grid-gap: 20px;
       margin-top: 25px;
        &__card  {
              width: auto;
              height: auto;
                 padding: 0px;;
            margin: 15px auto;
             margin-top: 45px;
           
            &__card-form {
            display: grid;
           
            grid-template-columns: 1fr ;
            justify-content: center;
            padding: 35px;


              &__label-input {
                margin-bottom: 55px;
                width: auto;
                border: none;
                font-size: 1rem;
                border-bottom: $el-L-Green 2px solid;
                background-color: transparent;
                font-family: $font-Catamaran;
            }

            &__label{
                  font-family: $font-Catamaran;
            }
            &__label-Texteara {
                background-color: $el-L-White2;
                border: 2px solid $el-L-Green;
                resize: none;
                width:  200px;
                padding: 10px;
                         font-size: 1rem;
                border-radius: 3px;
                font-family: $font-Pt_sans;
            }
            }

       &-SumitButton {
             
                background-color: $el-D-LiteDarkBlue;
                border: none;
                width: 100%;
                padding: 0px;
                margin: 10px auto;
                 margin-top: 25px;
                margin-bottom: 5px;
                padding-bottom: 5px;
               padding-top: 5px;
                color: $el-L-White;
                border-radius: 10px 10px 10px 10px;
                font-family: $font-Catamaran;
                font-weight: 700;
                font-size: 14px;
            }





            iframe{
                 width: auto;
                 height: 600px;
                 margin: auto;
            }
        }
          &__border-Line {
                display: none;
            }
    }

.errorne{
    display: none;
}
.error-to{
    display: block;
}


}












</style>
