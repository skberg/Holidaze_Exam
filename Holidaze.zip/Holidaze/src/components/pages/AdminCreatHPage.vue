<template>
    <div>
        <navbar></navbar>


        <div class="[ Card ]">
            <div class="[ Card-heding ]">
                <h1>Creating a new hotell</h1>
                <hr>
            </div>
              <div class="[ Card__error ]">
             <p v-if="errors.length">
                        <p class="[ Card__error-item ]" v-for="error in errors">{{ error }}</p>
                    </p>
              </div>
    
            <div class="[ Card__Holder ]">
                <form class="[ Card__Holder__form ]" method="POST" action="http://192.168.64.2/Holidaze/server/add-establishments-success.php" @submit="checkForm">
                
                    <label class="[ Card__Holder__form-Labal ]" for="establishmentName"><b>*</b>Establishment Name </label>
                    <input class="[ Card__Holder__form-Input ]" type="text" name="establishmentName" id="establishmentName" placeholder="Palo Holidaze" v-model="name">
    
                    <label class="[ Card__Holder__form-Labal ]" for="establishmentEmail"><b>*</b>Establishment Email</label>
                    <input class="[ Card__Holder__form-Input ]" type="text"  name="establishmentEmail" id="establishmentEmail" placeholder="firstnes@repetitoronlayn.ru" v-model="mail">
    
                    <label class="[ Card__Holder__form-Labal ]" for="imageUrl">Image URL:</label>
                    <input class="[ Card__Holder__form-Input ]" type="text" name="imageUrl" id="imageUrl" placeholder="https://unsplash.com/photos/BkmdKnuAZtw">
    
                    <label class="[ Card__Holder__form-Labal ]" for="price"><b>*</b>Price per person per night <samp>($)</samp></label>
                    <input class="[ Card__Holder__form-Input ]" type="number" placeholder="25.00$" name="price" id="price" v-model="pris">
    
                    <label class="[ Card__Holder__form-Labal ]" for="maxGuests"><b>*</b>Max guests</label>
                    <input class="[ Card__Holder__form-Input ]" type="number" placeholder="0"  min="0.0" name="maxGuests" id="maxGuests" v-model="guests">
    
                    <label class="[ Card__Holder__form-Labal ]" for="contryChosing"><b>*</b>Land</label>
                    <input class="[ Card__Holder__form-Input ]" type="text" name="contryChosing" id="contryChosing" v-model="land">
                     <label class="[ Card__Holder__form-Labal ]" for="adress"><b>*</b>Adress</label>
                    <input class="[ Card__Holder__form-Input ]" type="text"  name="adress" id="adress" v-model="adress">
                 
                    <label class="[ Card__Holder__form-Labal ]" for="description"><b>*</b>Description</label>
                    <input class="[ Card__Holder__form-Input ]" type="text" placeholder="This secluded wilderness cabin is the perfect spot for a restful and cosy getaway." name="description" id="description" v-model="description">
    
                    <label class="[ Card__Holder__form-Labal ]" for="shop">Distance to shop <samp>(Km)</samp></label>
                    <input class="[ Card__Holder__form-Input ]" type="number" placeholder="2km" min="0" name="shop" id="shop" >
                    
                    <label class="[ Card__Holder__form-Labal ]" for="cityC">Distance to City center<samp>(Km)</samp></label>
                     <input class="[ Card__Holder__form-Input ]" type="number" placeholder="1km"  min="0" name="cityC" id="cityC" >
                        
                     <label class="[ Card__Holder__form-Labal ]" for="id"><b>*</b>ID</label>
                    <input class="[ Card__Holder__form-Input ]" type="number" name="id" id="id" v-model="id">
                                     <div class="[ Card__Holder__form__selector ] ">
                                        <label class="[ Card__Holder__form__selector-Labal ]" for="selfCatering"><b>*</b>Self-catering</label>
                                        <div class="[ Card__Holder__form__selector__element ]">
                                            <label class="[ Card__Holder__form__selector-Labal ]" for="true">Yes</label>
                                            <input class="[ Card__Holder__form__selector-Radio ]" type="checkbox" id="true" name="selfCatering" value="Yes">
                                            <label class="[ Card__Holder__form__selector-Labal ]" for="false">No</label>
                                            <input class="[Card__Holder__form__selector-Radio ]" type="checkbox" id="false" name="selfCatering" value="No">
                                        </div>
                                    </div>
                                          <div class="[ Card__Holder__form__selector ] ">
                                        <label class="[ Card__Holder__form__selector-Labal ]" for="animal">Animale</label>
                                        <div class="[ Card__Holder__form__selector__element ]">
                                            <label class="[ Card__Holder__form__selector-Labal ]" for="true">Yes</label>
                                            <input class="[ Card__Holder__form__selector-checkbox ]" type="checkbox" id="true" name="animal" value="Yes">
                                            <label class="[ Card__Holder__form__selector-Labal ]" for="false">No</label>
                                            <input class="[ Card__Holder__form__selector-checkbox ]" type="checkbox" id="false" name="animal" value="No">
                                        </div>
                                 </div>
                                        <div class="[ Card__Holder__form__selector ] ">
                                        <label class="[ Card__Holder__form__selector-Labal ]" for="parking">Parking</label>
                                        <div class="[ Card__Holder__form__selector__element ]">
                                            <label class="[ Card__Holder__form__selector-Labal ]" for="true">Yes</label>
                                            <input class="[ Card__Holder__form__selector-checkbox ]" type="checkbox" id="true" name="parking" value="Yes">
                                            <label class="[ Card__Holder__form__selector-Labal ]" for="false">No</label>
                                            <input class="[ Card__Holder__form__selector-checkbox ]" type="checkbox" id="false" name="parking" value="No">
                                        </div>
                                 </div>
                                        <div class="[ Card__Holder__form__selector ] ">
                                         <label class="[ Card__Holder__form__selector-Labal ]" for="babyBead">babyBead</label>
                                        <div class="[ Card__Holder__form__selector__element ]">
                                            <label class="[ Card__Holder__form__selector-Labal ]" for="true">Yes</label>
                                            <input class="[ Card__Holder__form__selector-checkbox ]" type="checkbox" id="true" name="babyBead" value="Yes">
                                            <label class="[ Card__Holder__form__selector-Labal ]" for="false">No</label>
                                            <input class="[ Card__Holder__form__selector-checkbox ]" type="checkbox" id="false" name="babyBead" value="No">
                                        </div>
                                    </div>
                                    <div class="[ Card__Holder__form__selector ] ">
                                       <label class="[ Card__Holder__form__selector-Labal ]" for="tV">TV</label>
                                        <div class="[ Card__Holder__form__selector__element ]">
                                            <label class="[ Card__Holder__form__selector-Labal ]" for="true">Yes</label>
                                            <input class="[ Card__Holder__form__selector-checkbox ]" type="checkbox" id="true" name="tV" value="Yes">
                                            <label class="[ Card__Holder__form__selector-Labal ]" for="false">No</label>
                                            <input class="[ Card__Holder__form__selector-checkbox ]" type="checkbox" id="false" name="tV" value="No">
                                        </div>
                                    </div>
                    <input class="[ Card__Holder__form-Button ]" type="submit">
                </form>
            </div>
        </div>
    </div>
</template>

<script>
import Navbar from "../container/navbar/Navbar";
export default {
    name: 'AdminCreatHPage',
    components: {
        Navbar,
    },

    data() {
        return {
            errors: [],
            name: null,
            mail: null,
            pris: null,
            guests: null,
            land: null,
            Adress: null,
            description: null,
            id: null,
        }
    },
      methods: {
            checkForm: function(e) {

            if (this.name && this.mail && this.pris && this.guests && this.land && this.adress && this.description && this.id) return true;
            this.errors = [];

            if (!this.name) this.errors.push("Name required.");
            if (!this.mail) this.errors.push("e-mail required.");
            if (!this.pris) this.errors.push("Pris required.");
            if (!this.guests) this.errors.push("Gueste required.");
            if (!this.land) this.errors.push("Land required.");
            if (!this.adress) this.errors.push("Adress required.");
            if (!this.description) this.errors.push("Description required.");
            if (!this.id) this.errors.push("id required.");
            e.preventDefault();
        }
      }

}
</script>

<style lang="scss" scoped>
/*
bg = Background color
*/

/*
el = Element color
D = Dark
L = light
nr =  who position the color palette has in the style guide ( page 3 styleguide pdf "Color-deagram") 
*/

/* Fonts Importet form google font */

@import url('https://fonts.googleapis.com/css?family=Catamaran|PT+Sans|Quicksand|Raleway');
$font-Raleway: 'Raleway',
sans-serif;
$font-Catamaran: 'Catamaran',
sans-serif;
$font-Pt_sans: 'PT Sans',
sans-serif;
$font-Quicksand: 'Quicksand',
sans-serif;
/*Color*/

/*------------------*/

$bg-Color: #ffffff;
/*Blue Pallete nr.1*/

$el-L-ExstraLiteblue: #D7E2ED;
$el-L-Liteblue: #B6DBF2;
$el-L-Blue: #79ACD9;
$el-D-LiteDarkBlue: #416A8E;
$el-D-Darkblue: #323640;
/*Green Palette nr.2*/

$el-L-Green: #82BFBF;
$el-D-Green: #5E8A8A;
$el-D-ExstraliteGray: #BBBFBF;
$el-D-LiteDarkGray: #707373;
$el-D-DarkGray: #404141;
/*White pallette nr.3*/

$el-L-White: #FBFBFB;
$el-L-White2: #F6F6F6;
$el-L-White3: #FAFAFA;
$el-L-White4: #F0F0F0;
/*Exstra Color nr.4*/

$ek-D-Red: #B92025;
$ek-D-Blue: #17273F;
$ek-D-Gray: #E8E8E8;
::-webkit-input-placeholder { /* Chrome/Opera/Safari */
  color: white;
  opacity: 1; /* Firefox */
}
::-moz-placeholder { /* Firefox 19+ */
  color: white;
}
:-ms-input-placeholder { /* IE 10+ */
  color: white;
}
:-moz-placeholder { /* Firefox 18- */
opacity: 1; /* Firefox */
 color: white;
}


.Card {
    background-color: $el-D-Green;
     border-radius: 21px 21px 0px 0px;
    display: block;
    margin-left: auto;
    margin-right: auto;
    max-width: 1000px;
    height: auto;
   
       margin-top: 35px;
       &__error{

            &-item{
                display: grid;
              background-color: $ek-D-Red;
               font-family: $font-Pt_sans;
               color: #000;
               font-weight: 700;
               border: 2px solid rgb(117, 0, 0);
              width: 20%;
              border-radius: 5px;
              padding: 5px;
              margin: 25px auto;
              text-align: center;
            }
       }
    .Card-heding {
        text-align: center;
        padding-top: 10px;
        font-family: $font-Quicksand;
        
        border-radius: 10px;
       hr{
       border: 2px solid $el-L-Green;               /* side line */
         border-radius: 10px;
        width: 50%;

    }
    }
    
    b{
        color: $ek-D-Red;
        padding: 5px;
        opacity: 0.8;
    }
    samp{
        color:$el-D-Darkblue;
        margin-left:10px; 
          font-family: $font-Catamaran;
        font-weight: 700;
    }

    &__Holder {
        display: grid;
        grid-template-columns: 1fr ;
        justify-items: center;
        &__form {
            margin-top: 20px;
            display: grid;
            width: 65%;

            &__selector{
                display: grid;
                grid-template-columns: 1fr 1fr;

                margin:  auto;
                margin-top: 15px; 
                background-color: $el-D-Green;
                padding: 10px;
                width: auto;
                box-shadow: inset 0px 0px 8px 0px rgba(0,0,0,0.14);
                border-radius: 10px;
                &-Labal {
                font-size: 18px;
                font-family: $font-Catamaran;
                font-weight: 100;
                    padding-left: 15px;
                    text-align: left;
           
            
            }
                input{
                   
                    width: 30px;
                    padding: 25px;
                    padding-right:0px;   
                }
            }

            &-Labal {
                margin-top: 20px;
                font-size: 18px;
                font-family: $font-Catamaran;
                font-weight: 100;
                padding: 5px;
            
            }
            &-Input {
                padding: 15px;
                font-size: 1.1em;
                border-top: transparent;
                border-left: transparent;
                border-right: transparent;
                border-bottom: $el-L-Green 2px solid;
                width: 100%;
                background-color: transparent;
                color: black;
                placeholder {
  color: red;
  opacity: 1; /* Firefox */
}
            
            }
            &-Button {
                width: 50%;
                margin: 50px auto;
                padding: 15px;
                border-radius: 5px;
                border: none;
                background-color: $el-D-LiteDarkBlue;
                font-family: $font-Catamaran;
                font-weight: 700;
                font-size: 1.1em;
                color: $el-L-White;
            }
            &__element {
                background-color: $el-D-Green;
                width: 11%;
                padding: 10px;
                margin-top: 10px;
                display: inline-block;
                box-shadow: inset 0px 0px 6px 1px rgba(0,0,0,0.38);
                border-radius: 8px;
            }

            &__contryChouser{
                margin-top: 25px;
            }
        }
    }
}

@media screen and (max-width: 1050px) {
    /* show it on small screens */
    .Card {
        border-radius: 0px;


     &__error{

            &-item{
                display: grid;
              background-color: $ek-D-Red;
               font-family: $font-Pt_sans;
               color: #000;
               font-weight: 700;
               border: 2px solid rgb(117, 0, 0);
              width: auto;
              border-radius: 5px;
              padding: 5px;
              margin: 10px auto;
              text-align: center;
            }
       }





        &__Holder {
            border-radius: 0px;
            margin: auto;

             &__form {
             &__element{
              
                 justify-content: center;
                 margin: auto;
             }
             }
        }
    }
}
</style>

