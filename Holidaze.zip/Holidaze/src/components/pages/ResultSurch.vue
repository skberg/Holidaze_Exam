<template>
    <div v-on="filterbyContry(criteria)">
        <navbar></navbar>
        <div class="[ E-holder ]">
            <input class="[ E-holder__input ]" v-model="criteria" type="text" list="languages" />
            <datalist class="data" id="languages">
                    <option v-for="item in items">{{item.contryChosing}}</option>                
                </datalist>
    
            <!--the filteritems function must only run when this button is clicked-->
            <button class="[ E-holder__Button ]" type="submit" v-on:click="filterbyContry(criteria)">search </button>
        </div>
        <div class="[ card ]" v-for="item in filteredItems">
            <div class="[ card__items-holder ]">
                <div class="[ card__items-holder__border ]">
                    <img class="[ card__items-holder__border__img ]" v-bind:src="item.imageUrl" alt="img">
                </div>
                <div class="[ card__items-holder__text ]">
                    <h1>{{ item.establishmentName }}</h1>
    
                    <h3 class="[ card__items-holder__prise ]"> {{ item.price }} $</h3>
                    <h4>{{ item.contryChosing}}</h4>
    
                    <p class="[ card__items-holder__text__descritp ]">{{ item.description}}</p>
    
                </div>
            </div>
            <div class="[ button__holder ]">
                <router-link class="[ button__holder__item ]" :to="{ path:`/HomePage/${item.id}`}">learn more</router-link>
            </div>
        </div>
    
        <fotter></fotter>
    
    
    </div>
</template>

<script>
import Fotter from "../container/Fotter/Fotter";
import Navbar from "../container/navbar/Navbar";

export default {
    name: 'ResultPage',
    components: {


        Navbar,
        Fotter,
    },
    data() {
        return {
            item: '',
            filteredItems: [],
            criteria: localStorage.SearchQuery,
            errors: [],
            name: null,
            items: [],


        }
    },

    created() {
        this.getitems();
    },

    methods: {
        getitems: function() {
            fetch('establishments.json')
                .then((response) => {
                    return response.json()
                })
                .then((result) => {
                    this.items = result;
                })
                .catch(err => {
                    console.log(err);
                });
        },
        filterbyContry(SearchQuery) {
            if (this.items.length !== 0) {
                this.filteredItems = this.items.filter((value) => {
                    return value.contryChosing === SearchQuery;
                })
            } else {
                console.log('no data')
            }
        },

   created() {
        this.getitems();
        this.filterbyContry(criteria);
    },
    


    }


    
}
</script>


<style lang="scss" scoped>
/*
bg = Background color
*/

/*
el = Element color
D = Dark
L = light
nr =  who position the color palette has in the style guide ( page 3 styleguide pdf "Color-deagram") 
*/

/* Fonts Importet form google font */

@import url('https://fonts.googleapis.com/css?family=Catamaran|PT+Sans|Quicksand|Raleway');
$font-Raleway: 'Raleway',
sans-serif;
$font-Catamaran: 'Catamaran',
sans-serif;
$font-Pt_sans: 'PT Sans',
sans-serif;
$font-Quicksand: 'Quicksand',
sans-serif;
/*Color*/

/*------------------*/

$bg-Color: #ffffff;
/*Blue Pallete nr.1*/

$el-L-ExstraLiteblue: #D7E2ED;
$el-L-Liteblue: #B6DBF2;
$el-L-Blue: #79ACD9;
$el-D-LiteDarkBlue: #416A8E;
$el-D-Darkblue: #323640;
/*Green Palette nr.2*/

$el-L-Green: #82BFBF;
$el-D-Green: #5E8A8A;
$el-D-ExstraliteGray: #BBBFBF;
$el-D-LiteDarkGray: #707373;
$el-D-DarkGray: #404141;
/*White pallette nr.3*/

$el-L-White: #FBFBFB;
$el-L-White2: #F6F6F6;
$el-L-White3: #FAFAFA;
$el-L-White4: #F0F0F0;
/*Exstra Color nr.4*/

$ek-D-Red: #B92025;
$ek-D-Blue: #17273F;
$ek-D-Gray: #E8E8E8;
.error {
    background-color: $el-L-Green;
    color: $el-D-DarkGray;
    font-weight: 700;
    text-align: center;
    margin: auto;
    height: 30px;
    margin-bottom: -18px;
    max-width: 700px;
    padding: 0px;
    padding-top: 20px;
    z-index: -1;
    border-radius: 10px 10px 0px 0px;
    animation: mymove 0.8s;
}

@keyframes mymove {
    from {
        height: 0px;
    }
    to {
        height: 30px;
    }
}

.E-holder {
    margin: auto;
    padding: 35px;
    z-index: 1;
    max-width: 1100px;
    border-radius: 10px;
    background-color: $el-D-Darkblue;
    &__input {
        width: 100%;
        display: grid;
        grid-template-columns: 1fr 1fr;
        border-radius: 3px 3px 0px 0px;
        height: 40px;
        margin-top: 5px;
        border: none;
        padding: 5px;
        font-size: 17px;
        justify-content: center;
    }
    &__row {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr;
        grid-gap: 1px;
        text-align: center;
        padding: 15px;
        width: 700px;
        margin: auto;
        justify-items: center;
    }
    .E-holder__Button {
        display: block;
        margin-top: 30px;
        margin-left: auto;
        margin-right: 30px;
        cursor: pointer;
        background-color: $el-D-LiteDarkBlue;
        border-radius: 5px;
        color: $el-L-White;
        font-family: $font-Catamaran;
        font-style: bold;
        border: none;
        width: 100px;
        font-size: 17px;
        color: #ffff;
    }
}

.card {
    background-color: $el-L-White2;
    margin: 15px auto;
    width: 1000px;
    padding: 40px;
    border-radius: 10px;
    box-shadow: 0px 0px 2px 0px rgba(0, 0, 0, 0.201);
    &__items-holder {
        display: flex;
        &__border {
            border: 8px solid $el-L-Green;
            border-radius: 90%;
            padding: 3px;
            height: 250px;
            width: 250px;
            &__img {
                height: 250px;
                width: 250px;
                border-radius: 90%;
            }
        }
        &__prise {
            font-family: $font-Pt_sans;
            font-weight: 700;
            font-size: 25px;
            color: $ek-D-Red;
        }
        &__text {
            font-family: $font-Pt_sans;
            padding-left: 50px;
            padding-top: 20px;
            width: 60%;
            &__descritp {
                border-radius: 1px;
                width: 100%;
            }
        }
    }
    .button__holder {
        &__item {
            padding: 5px;
            width: 100px;
            margin-bottom: 20px;
            float: right;
            background-color: $el-D-LiteDarkBlue;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            color: $el-L-White;
            font-family: $font-Catamaran;
            font-style: bold;
            border: none;
            font-size: 15px
        }
    }
}

@media screen and (max-width: 1050px) {
    /* show it on small screens */
    .card {
        width: auto;
        align-items: center;
        justify-content: center;
        margin: 15px;
        height: auto;
        &__items-holder {
            align-items: center;
            justify-content: center;
            flex-direction: column;
            &__border {
                border: 8px solid $el-L-Green;
                border-radius: 90%;
                &__img {
                    border-radius: 90%;
                }
            }
            &__prise {
                font-family: $font-Pt_sans;
                font-weight: 700;
                font-size: 25px;
                color: $ek-D-Red;
            }
            &__text {
                font-family: $font-Pt_sans;
                align-items: center;
                justify-content: center;
                text-align: left;
                padding: 0px;
                width: 100%;
            }
        }
        .button__holder {
            display: flex;
            align-items: center;
            justify-content: center;
            &__item {
                padding: 5px;
                width: 110px;
            }
        }
    }
}

/*needs som work */

@media screen and (max-width: 800px) {
    .E-holder {
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        border-radius: 0px;
        &__input {
            border-radius: 5px;
            border: transparent;
            margin-bottom: 10px;
        }
        &__row {
            width: auto;
            margin: auto;
        }
        .E-holder__Button {
            display: block;
            margin-top: 30px;
            margin-left: auto;
            margin-right: auto;
            cursor: pointer;
            background-color: $el-D-LiteDarkBlue;
            border-radius: 5px;
            color: $el-L-White;
            font-family: $font-Catamaran;
            font-style: bold;
            border: none;
            font-size: 17px;
            color: #ffff;
        }
    }
}
</style>
