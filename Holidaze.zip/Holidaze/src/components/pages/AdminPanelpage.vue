<template>
    <div>
    
    
    
    
    
    
        <div class="[ navbar ]">
    
            <div class="[ nav-icon ]">
                <img class="[ nav-icon-img ]" src="../../assets/Icons/Dashbord.svg" alt="img" align="middle">
    
            </div>
    
            <ul class="[ navbar__listing ]">
    
                <router-link class="[ Router-style ]" to="/AdminCreatHPage">
                    <li class="[ navbar__listing-element  ]"><a>Create new hotell</a></li>
                </router-link>
    
                <router-link class="[ Router-style ]" to="/AdminOrderPage">
                    <li class="[ navbar__listing-element  ]"><a>Order</a></li>
                </router-link>
    
                <router-link class="[ Router-style ]" to="/">
                    <li class="[ navbar__listing-element  ]"><a>Home</a></li>
                </router-link>
    
            </ul>
        </div>
    

     
 
            <div class="[ Lite-navbar ]">
    
                <router-link class="[ Router-style ]" to="/AdminCreatHPage">
                    <p class="[ Lite-navbar-element  ]">
                        <a> Create new hotell</a>
                        </p>
                </router-link>
    
                <router-link class="[ Router-style ]" to="/AdminOrderPage">
                    <p class="[ Lite-navbar-element  ]">
                        <a>Order</a>
                    </p>
                </router-link>
    
                <router-link class="[ Router-style ]" to="/">
                    <p class="[ Lite-navbar-element  ]">
                        <a>Home</a>
                    </p>
                </router-link>
            </div>

          
    
   
    


        
    
    
    
        <div id="myDIV" class="[ alert ]">
            <h1 class="[ alert__heding ]">HEY THERE!</h1>
            <p class="[ alert__heding-text ]">New here? On this page you will be able to find an overview of your orders and you have the opportunity to create new hotels.  </p>
            <b>have a nice day, from everyone here in holidaze</b>
        </div>
    
        <img src="../../assets/Icons/Dragdoneline.svg" class="[ cnet ]" v-on:click=" Hingme"></img>
    
    
    
        <div class="[ Holder-card ]">
            <div class="[ card ]">
    
                <router-link class="[ Router-style ]" to="AdminCreatHPage">
                    <p class="[ card-heding ]">Create new hotell</p>
                    <img class="[ card-img ]" src="../../assets/Icons/HomePluss.svg" alt="img" align="middle">
                </router-link>
                <router-link class="[ Router-style ]" to="AdminCreatHPage">
                    <div class="[ card-button_holder ]">
                        <button class="[ card-button_holder-Mybutton-Green  ]">Creat new hotell</button>
                    </div>
                </router-link>
    
            </div>
    
    
    
    
            <div class="[ card ]">
                <router-link class="[ Router-style ]" to="AdminOrderPage">
                    <p class="[ card-heding ]">Order</p>
                    <img class="[ card-img ]" src="../../assets/Icons/Order.svg" alt="img" align="middle">
    
                </router-link>
                <router-link class="[ Router-style ]" to="AdminOrderPage">
                    <div class="[ card-button_holder ]">
                        <button class="[ card-button_holder-Mybutton-Blue  ]">Order</button>
                    </div>
                </router-link>
            </div>
    
        </div>
    
    
    </div>
</template>

<script>
export default {
    name: "AdminPanelpage",

    components: {

    },


    created() {
        this.Hingme();

    },

    methods: {
        Hingme: function myFunction() {
            var x = document.getElementById("myDIV");

         if (x.style.display === "none") {

                x.style.display = "block";


            } else {
                x.style.display = "none";
            } 
        },





    }

}
</script>

<style lang="scss" scoped>
/*
bg = Background color
*/

/*
el = Element color
D = Dark
L = light
nr =  who position the color palette has in the style guide ( page 3 styleguide pdf "Color-deagram") 
*/

/* Fonts Importet form google font */

@import url('https://fonts.googleapis.com/css?family=Catamaran|PT+Sans|Quicksand|Raleway');
$font-Raleway: 'Raleway',
sans-serif;
$font-Catamaran: 'Catamaran',
sans-serif;
$font-Pt_sans: 'PT Sans',
sans-serif;
$font-Quicksand: 'Quicksand',
sans-serif;
/*Color*/

/*------------------*/

$bg-Color: #ffffff;
/*Blue Pallete nr.1*/

$el-L-ExstraLiteblue: #D7E2ED;
$el-L-Liteblue: #B6DBF2;
$el-L-Blue: #79ACD9;
$el-D-LiteDarkBlue: #416A8E;
$el-D-Darkblue: #323640;
/*Green Palette nr.2*/

$el-L-Green: #82BFBF;
$el-D-Green: #5E8A8A;
$el-D-ExstraliteGray: #BBBFBF;
$el-D-LiteDarkGray: #707373;
$el-D-DarkGray: #404141;
/*White pallette nr.3*/

$el-L-White: #FBFBFB;
$el-L-White2: #F6F6F6;
$el-L-White3: #FAFAFA;
$el-L-White4: #F0F0F0;
/*Exstra Color nr.4*/

$ek-D-Red: #B92025;
$ek-D-Blue: #17273F;
$ek-D-Gray: #E8E8E8;
body {
    background-color: $bg-Color;
}

.cnet {
    display: block;
    margin: 10px auto;
    width: 40px;

}

.alert {
    background-color: $el-L-White3;
    padding: 15px;
    width: auto;;
    max-width: 800px;
    margin: auto;
   height: auto;
    margin-top: 0px;
    border-radius: 0px 0px 10px 10px;
    box-shadow: 0px 0px 3px 0px rgba(0, 0, 0, 29%);
    animation: mymove 18ms ease-in-out;
   

    &__heding {
        color: $el-D-DarkGray;
        text-decoration: underline $el-L-Green;
          font-family: $font-Quicksand;
            font-weight: 900;
        
        &-text {
            font-family: $font-Pt_sans;
            font-size: 1.0em;
        }
    }
    b{
        font-size: 0.8rem;
        font-family: $font-Raleway;
        font-weight: 100;
        color: $el-D-Darkblue;
    }
}

@keyframes mymove {
  from {height: 0px;}
  to {height: 100px;}
}



.Router-style {
    color: #323640;
    text-decoration: none;
}

.navbar {
    background-color: $el-L-White2;
    height: 100%;
    width: 200px;
    position: fixed;
    z-index: 0;
    top: 0;
    left: 0;
    overflow: hidden;
    padding-top: 20px;
    padding-top: 60px;
    border-right: $el-L-Green 2px solid;
    
    .nav-icon{

            &-img {
                box-shadow: 0px 0px 3px 0px rgba(0, 0, 0, 29%);
                border-radius: 90%;
                height: 90px;
                display: block;
                margin: auto;
            }
    }

    &__listing {
        margin: 0 !important;
       padding-left: 0px;
        padding-top: 20px;
        &-element {
            list-style-type: none;
            border-bottom: $el-L-Green 2px solid;
            width: 70%;
            margin-top: 22px;
            padding: 5px 3px;
            font-family: $font-Quicksand;
            font-weight: 700;
            font-size: 0.9rem
        }
    }
}

.Lite-navbar {
      
        border-bottom: $el-L-Green 2px solid;
        justify-content: center;
        max-width: 100%;
        text-align: center;
       
        &-element {
            list-style-type: none;
            display: inline-block;
            padding: 10px;
            text-align: center;
            margin: auto;
            font-family: $font-Quicksand;
        }
    }










.Holder-card {
    display: grid;
    grid-template-columns: auto auto;
    grid-gap: 85px;
    justify-content: center;
    margin: 20px auto;
    font-size: 18px;
    justify-items: center;

    .card {
        background-color: #FBFBFB;
        height: 400px;
        width: 400px;
        border-radius: 21px;
        box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 29%);
        &-heding {
            text-align: center;
            font-family: $font-Quicksand;
            font-weight: 700;
        }
        &-img {
            width: 200px;
            display: block;
            margin-left: auto;
            margin-right: auto;
            margin-top: 65px;
        }



        .card-button_holder{
                
                
                &-Mybutton-Blue {
                    display: block;
                    background-color: $el-D-LiteDarkBlue;
                    color: $el-L-White;
                    font-family: $font-Catamaran;
                    font-weight: 800;
                    border: none;
                    margin-left: auto;
                    margin-right: auto;
                    margin-top: 67px;
                    border-radius: 10px;
                    padding: 10px;
                    width: 72%;
                    font-size: 20px
                }
                &-Mybutton-Green {
                    display: block;
                    background-color: $el-D-Green;
                    color: $el-L-White;
                    font-family: $font-Catamaran;
                    font-weight: 800;
                    border: none;
                    margin-left: auto;
                    margin-right: auto;
                    margin-top: 120px;
                    border-radius: 10px;
                    padding: 9px;
                    width: 72%;
                    font-size: 20px
                }
            }
    }
}

@media screen and (max-width: 1050px) {
    /* show it on small screens */
    .Holder-card {
        grid-template-columns: repeat(auto-fill, minmax(450px, 1fr));
        width: auto;;
        .card {

            width: 50%;;
            padding: 10px;
            margin: 15px auto;
            border-radius: 20px;
            
   &-img {
            width: 180px;
            display: block;
            margin-left: auto;
            margin-right: auto;
            margin-top: 65px;
        }




  .card-button_holder{
                
                
                &-Mybutton-Blue {
                    display: block;
                    background-color: $el-D-LiteDarkBlue;
                    color: $el-L-White;
                    font-family: $font-Catamaran;
                    font-weight: 800;
                    border: none;
                    margin-left: auto;
                    margin-right: auto;
                    margin-top: 100px;
                    border-radius: 5px;
                    padding: 10px;
                    width: 72%;
                    font-size: 20px
                }
                &-Mybutton-Green {
                    display: block;
                    background-color: $el-D-Green;
                    color: $el-L-White;
                    font-family: $font-Catamaran;
                    font-weight: 800;
                    border: none;
                    margin-left: auto;
                    margin-right: auto;
                  margin-top: 150px;
                    border-radius: 5px;
                    padding: 9px;
                    width: 72%;
                    font-size: 20px
                }
            }





        }
    }
    .alert{
        border-radius: 0px;
    }


}



/* The "responsive" class is added to the topnav with JavaScript when the user clicks on the icon. This class makes the topnav look good on small screens (display the links vertically instead of horizontally) */



@media screen and (max-width: 500px) {
  .Lite-navbar {
     
    
    
        &-element  {
           text-align: justify;
            display: block;
     
            

        }


        &-element a{
            background-color: #416A8E;
            padding: 5px;
            border-radius: 5px;
            color: #ffff;
             font-family: $font-Catamaran;
             width: 20px;
        }

     }
         
  }
   




@media screen and( max-width:1424px) {
    .Lite-navbar {
        display: block;
        
    }
    .navbar {
        display: none;
    }
    .Holder-card {
        justify-content: center;
    }
}

@media screen and( min-width:1325px) {
    .Lite-navbar {
        display: none;
    }
    .navbar {
        display: block;
    }
    .Holder-card {
        justify-content: center;
        margin: auto;
        margin-top: 100px;
     
    }
}
</style>
