<template>
    <div>
        <navbar></navbar>
     <div class="[ hombutton ]">
                <router-link to="/ResultPage">
                    <img src="../../assets/Icons/LefBlue.svg" alt="hedicone" width="40">
                </router-link>
            </div>
    
    
        <div class="[ Holder ]" v-for="hotel in filteredArray">
            <div class="[  Holder__grid-img ]">
                <div class="[ Holder__grid-img-border ]">
                    <img class="[  Holder__grid-img-border__grid-maine ]" v-bind:src="hotel.imageUrl" alt="img1" />
                </div>
      <div class="[  Holder__grid-img_secund ]">
            


      </div>
    
    
            </div>
    
        </div>
    
    
    
    
        <div class="[ inforplac ]" v-for="hotel in filteredArray">
    
            <div class="[ inforplac__Main ]" >
    
                <h1 class="[ inforplac__Main__Heding ]"> {{hotel.establishmentName}}</h1>
                <h2 class="[ inforplac__Main__Price ]">{{hotel.price}} $</h2>
                <h4 class="[ inforplac__Main__Price ]"><i class="fas fa-map-marked-alt"></i>{{hotel.adress}}</h4>
                <p class="[ inforplac__Main__Texst ]">{{hotel.description}}</p>
    
    
    
            </div>
    
            <div class="[ inforplac__Main--secund ]" v-for="hotel in filteredArray">
                <div class="[ inforplac__button ]">
                    <div class="[ inforplac__button-items ]">
                        <img class="[ inforplac__button-items__itemone ]" src="../../assets/Icons/Dinner.svg" />
                        <h4 class="[ inforplac__button-items__itemto ]">Dinner: {{hotel.selfCatering}}</h4>
    
                    </div>
    
    
                </div>
                <div class="[ inforplac__button ]">
                    <div class="[ inforplac__button-items ]">
                        <img class="[ inforplac__button-items__itemone ]" src="../../assets/Icons/Geust.svg" />
                        <h4 class="[ inforplac__button-items__itemto ]"> Max-Guests: {{hotel.maxGuests}}</h4>
                    </div>
    
    
                </div>
                <div class="[ inforplac__button ]">
                    <div class="[ inforplac__button-items ]">
                        <img class="[ inforplac__button-items__itemone ]" src="../../assets/Icons/Map.svg" />
                        <h4 class="[ inforplac__button-items__itemto ]"> Country: {{hotel.contryChosing}}</h4>
                    </div>
                </div>
    


    
            </div>
            <router-link class="[ button ]" :to="{ path:`/EnquiryPage/${hotel.id}`}">
    
                Booking
            </router-link>
    
        </div>
    
    
    
    
    
        <div class="[ holder ]">
    
            <ul class="[ holder-list__1 ]" v-for="hotel in filteredArray">
                <h4 class="[ holder-list__1-heding ]">Room facilities</h4>
                <li><i class="fas fa-paw"></i>Animal: {{hotel.animal}}</li>
                <li><i class="fas fa-baby"></i>BabyBed: {{hotel.babyBead}} </li>
                <li><i class="fas fa-tv"></i>TV: {{hotel.tV}}</li>
    
            </ul>
    
            <ul class="[ holder-list__2 ]" v-for="hotel in filteredArray">
                <h4 class="[ holder-list__2-heding ]">Amenities nearby</h4>
                <li><i class="fas fa-city"></i>Distance from City center: {{hotel.CityCenter}}</li>
                <li><i class="fas fa-store"></i>Distance from shopping mall: {{hotel.store}}</li>
                <li><i class="fas fa-parking"></i>Parking: {{hotel.parking}} </li>
    
    
            </ul>
    
        </div>

    
        <div class="[ coments ]">

       <p v-if="errors.length">
                        <p class="error-to" v-for="error in errors">{{ error }}</p>
                    </p>
        
                 <h1 class="[ coments-heding ]">Comments </h1>
            <form class="[ coments__items ]" method="POST" action="http://192.168.64.2/Holidaze/server/Coments-sucess.php" @submit="checkForm">
            
            <input class="[ coments__items__name ]" type="text" name="name"  placeholder="Name" v-model="name"/>
         
        <textarea  name="comment" form="usrform">Enter text here...</textarea>   
          <input class="[ coments__items-input ]" type="submit" /> 
           
       
</form>
         </div>
                                        
     
   
    
    
        <fotter></fotter>
    
    </div>
</template>

<script>
import Navbar from "../container/navbar/Navbar";
import Fotter from "../container/Fotter/Fotter";
import ResultSurch from "./ResultSurch";

export default {
    name: 'HomePage',
    components: {
        Navbar,
        ResultSurch,
        Fotter,

    },

    data() {
        return {
            allitem: [],
            sef: [],
            filteredArray: [],
            hotel: "",
             errors: [],
            name: null,
        
        }
    },


    created() {
        this.getignData()
        console.log('this.$route.params.id', this.$route.params.id)
        // do you see this is now in the console?
        // so you going to do what you did on the previous page
    },

    methods: {
        getignData: function() {
            fetch('../establishments.json')
                .then((response) => {
                    return response.json()
                })
                .then((result) => {
                    this.allitem = result;
                    this.filteredArray = result.filter((value) => {
                        return value.id === this.$route.params.id
                    })
                    console.log(this.filteredArray)

                })
                .catch(err => {
                    console.log(err);

                });
        },

    checkForm: function(e) {

            if (this.name ) return true;
            this.errors = [];

            if (!this.name) this.errors.push("Name required.");
         
            e.preventDefault();
        }





        

    },


}
</script>

<style lang="scss" scoped>
/*
bg = Background color
*/

/*
el = Element color
D = Dark
L = light
nr =  who position the color palette has in the style guide ( page 3 styleguide pdf "Color-deagram") 
*/

/* Fonts Importet form google font */

@import url('https://fonts.googleapis.com/css?family=Catamaran|PT+Sans|Quicksand|Raleway');
$font-Raleway: 'Raleway',
sans-serif;
$font-Catamaran: 'Catamaran',
sans-serif;
$font-Pt_sans: 'PT Sans',
sans-serif;
$font-Quicksand: 'Quicksand',
sans-serif;
/*Color*/

/*------------------*/

$bg-Color: #ffffff;
/*Blue Pallete nr.1*/

$el-L-ExstraLiteblue: #D7E2ED;
$el-L-Liteblue: #B6DBF2;
$el-L-Blue: #79ACD9;
$el-D-LiteDarkBlue: #416A8E;
$el-D-Darkblue: #323640;
/*Green Palette nr.2*/

$el-L-Green: #82BFBF;
$el-D-Green: #5E8A8A;
$el-D-ExstraliteGray: #BBBFBF;
$el-D-LiteDarkGray: #707373;
$el-D-DarkGray: #404141;
/*White pallette nr.3*/

$el-L-White: #FBFBFB;
$el-L-White2: #F6F6F6;
$el-L-White3: #FAFAFA;
$el-L-White4: #F0F0F0;
/*Exstra Color nr.4*/

$ek-D-Red: #B92025;
$ek-D-Blue: #17273F;
$ek-D-Gray: #E8E8E8;
$ek-L-Gray: #707070;
body {
    background-color: $bg-Color;
    margin: 0 !important;
    padding: 0 !important;
}
.hombutton{
    margin: 15px;;
}

  
.Holder {
    padding: 25px;
    max-width: 1300px;
    margin: auto;
    &__grid-img {
        display: grid;
        justify-items: center;
        &-border {
            border: $el-L-Blue 5px solid;
            border-radius: 100%;
            padding: 5px;
            &__grid-maine {
                padding: 1px;
                height: 480px;
                border-radius: 90%;
                width: 480px;
            }
        }
    }
}

.inforplac {
    background-color: #FBFBFB;
    border-radius: 20px;
    color: black;
    padding: 20px;
    display: grid;
    max-width: 1300px;
    margin: 25px auto;
    z-index: 1;
    grid-template-columns: 1fr 1fr;
    box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 0.16);
    &__Main {
        display: grid;
        padding: 20px;
        &__Heding {
            font-family: $font-Quicksand;
            font-weight: 100;
            color: $ek-L-Gray;
        }
        &__Price{
              font-family:$font-Pt_sans;
              font-weight: 700;
              color: $el-D-DarkGray;

        }
        &__Texst {
            font-family: $font-Pt_sans;
            font-weight: 100;
          
            font-size: 15px;
        }
    }
    &__button {
        &-items {
            display: flex;
            justify-content: left;
            margin-left: 85px;
            margin-top: 24px;
            &__itemone {
                justify-content: center;
                border-radius: 90%;
                box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 0.16);
                width: 55px;
                height: 55px;
            }
            &__itemto {
                margin-top: 24px;
                margin-left: 55px;
                font-family: $font-Pt_sans;
                color: $el-D-DarkGray;
            }
        }
    }
    &__Main--secund {
        border-left: 2px solid $el-L-Green;
    }
        i {
        color: $el-L-Blue;
        margin-right: 15px;
        padding: 5px;
        margin: 5px;
    }
}

.holder {
    background-color: #F0F0F0;
    max-width: 1200px;
    margin: auto;
    margin-top: -40px;
    margin-bottom: 55px;
    position: relative;
    border-radius: 21px;
    padding: 10px;
    z-index: -1;
    display: grid;
    grid-template-columns: 1fr 1fr;
    box-shadow: 0px 1px 3px 0px rgba(0, 0, 0, 0.199);
    font-family: $font-Pt_sans;
    font-weight: 700;
    &-list__1 {
        margin: auto;
        width: 70%;
        text-align: left;
        list-style-type: none;
        color: $el-D-DarkGray;
        font-size: 1rem;
        &-heding {
            border-bottom: 2px solid $el-L-Blue;
            width: 70%;
            text-align: center;
        }
    }
    &-list__2 {
        margin: auto;
        width: 70%;
        text-align: left;
        padding-left: 25px;
        list-style-type: none;
        color: $el-D-DarkGray;
        &-heding {
            border-bottom: 2px solid $el-L-Blue;
            width: 70%;
            text-align: center;
        }
    }
    i {
        color: $el-L-Blue;
        margin-right: 15px;
        text-align: center;
        padding: 5px;
        ;
        margin: 5px;
    }
}

.button {
    display: grid;
    background-color: $el-D-LiteDarkBlue;
    margin: 15px;
    width: 20%;
    text-decoration: none;
    text-align: center;
    color: $el-L-White;
    border-radius: 5px;
    font-family: $font-Catamaran;
    font-weight: 700;
    font-size: 14px;
}

.coments {
    display: block;
    margin: 25px auto;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 20px;
    margin-top: 35px;
    height: 100%;
    border-radius: 10px;
    background-color: $el-L-White4;
    max-width: 1500px;
    &-heding {
        border-bottom: 2px solid $el-D-Green;
        width: 20%;
    }
    &__items {
        background-color: $el-L-White3;
        box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 0.16);
        padding: 25px;
        border-radius: 10px;
        width: 100%;
        margin: 45px auto;
        max-width: 900px;
        
        &-input {
        background-color: $el-D-LiteDarkBlue;
        margin: 15px;
        
        width: 20%;
        text-decoration: none;
        text-align: center;
        color: $el-L-White;
        border-radius: 5px;
        font-family: $font-Catamaran;
        font-weight: 700;
        font-size: 14px;
        border: none;
         margin-left: 34px;
       
        }
         &__name{
            width: 25%;
            padding: 5px;
            margin-bottom: 10px;
            margin-left: 34px;
            border-radius: 2px;
            border: 2px solid $el-L-Blue;
        }
        textarea {
            resize: none;
            display: block;
            margin-top: 10px;
            padding: 10px;
            width: 90%;
            margin: auto;
              border: 1px solid $ek-L-Gray
          
        }
    }
}


.error-to {
    text-align: center;
    background-color: $el-L-Green;
    color: $el-D-DarkGray;
    width: 10%;
    border-radius: 0px 0px 5px 0px;
    padding: 7px;
     
}


 






























@media screen and (max-width: 1000px) {
    .Holder {
        width: auto;
        margin: auto;
        &__grid-img {
            justify-items: center;
            &-border {
                border: white 5px solid;
                border-radius: 10px;
                &__grid-maine {
                    border-radius: 5px;
                    width: 100%;
                    height: auto;;
                  
                }
            }
        }
    }






























.inforplac {
        display: grid;
           grid-template-columns: 1fr;
        border-radius: 0px;
        color: black;
      
        width: auto;;
        max-width: 1300px;
       width: auto;
  
        z-index: 1;

    &__Main {
      
       
        &__Heding {
            font-family: $font-Quicksand;
            font-weight: 100;
            color: $ek-L-Gray;
        }
        &__Price{
              font-family:$font-Pt_sans;
              font-weight: 700;
              color: $el-D-DarkGray;

        }
        &__Texst {
            font-family: $font-Pt_sans;
            font-weight: 100;
          
            
            
        }
    }

&__button {
    
        &-items {            
         margin-left: 10px;
         margin-top: 0px;
            &__itemone {
                border-radius: 90%;
                box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 0.16);
                margin-left: 0px;
              
                          }
            &__itemto {
                text-align: left;
                float: left;
                margin-top: 20px;
                margin-left: 5px;
                font-family: $font-Pt_sans;
                color: $el-D-DarkGray;
            }
        }
    }

}




.holder {
    display: grid;
     grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    background-color: #F0F0F0;
    max-width: 1200px;
    margin: auto;
    margin-top: -40px;
    margin-bottom: 55px;

    border-radius: 21px;
   
    z-index: -1;
  
   
    box-shadow: 0px 1px 3px 0px rgba(0, 0, 0, 0.199);
    font-family: $font-Pt_sans;
    font-weight: 700;
    
    
    
        &-list__1 {
       justify-content: center;
      
      
        list-style-type: none;
        color: $el-D-DarkGray;
       
        &-heding {
            border-bottom: 2px solid $el-L-Blue;
            width: 70%;
            text-align: center;
        }
    }


    &-list__2 {
        margin: auto;
        
    
    
        list-style-type: none;
        color: $el-D-DarkGray;
        &-heding {
            border-bottom: 2px solid $el-L-Blue;
            width: 70%;
            text-align: center;
        }
    }
    i {
        color: $el-L-Blue;
        margin-right: 15px;
        text-align: center;
        padding: 5px;
        margin: 5px;
    }
}






.coments {
    margin: auto;
   
    
    width: auto;
    border-radius: 10px;
 
    
    &-heding {
        border-bottom: 2px solid $el-D-Green;
       
    }
    &__items {
        background-color:$el-L-White3;
        box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 0.16);

        border-radius: 10px;
        width: auto;
  
        max-width: 900px;
        &-input {
        background-color: $el-D-LiteDarkBlue;
        margin: 15px;
        width: 30%;
        text-decoration: none;
        text-align: center;
        color: $el-L-White;
        border-radius: 5px;
        font-family: $font-Catamaran;
        font-weight: 700;
        font-size: 14px;
        border: none;

       
        }
         &__name{
              width: auto;
              margin: auto;
              
            padding: 5px;
            border-radius: 2px;
            border: 2px solid $el-L-Blue;
        }
        textarea {
            resize: none;
            display: block;
            margin: auto;
            width: 90%;
            margin-top: 10px;
            padding: 10px;
              border: 1px solid $ek-L-Gray
          
        }
    }


}

      

























}

 @media screen and (max-width: 1057px) {
    .button {
        width: 50%;
        
        background-color: $el-D-LiteDarkBlue;
        margin:  auto;
        text-decoration: none;
        text-align: center;
        color: $el-L-White;
        border-radius: 5px;
        font-family: $font-Catamaran;
        font-weight: 700;
        font-size: 14px;
        
    }

} 
</style>
