<template>
    <div>
    
        <navbar></navbar>
        <div class="[ Card ]">
    
            <div class="[ Card__hombutton ]">
                <router-link to="/AdminPanelpage">
                    <img src="../../assets/Icons/LefBlue.svg" alt="hedicone" width="40">
                </router-link>
            </div>
            <div class="[ Card__heding ]">
                <h1>Orders</h1>
                <hr class="[ Card__heding_hr ]">
            </div>
    
            <div class="[ Card__heding-elemetn ]" v-for="item  in allOrder">
                <router-link class="[ Card__heding-elemetn__item ]" :to="{ path:`/AdminOrderListing/${item.clientName}`}">
                    <img class="[ Card__heding-elemetn__item-1 ]" src="../../assets/Icons/LefBlue.svg" width="50" alt="img">
                    <p class="[ Card__heding-elemetn__item-2 ]">#{{item.clientName}}</p>
                </router-link>
            </div>
    
        </div>
    </div>
</template>


<script>
import Navbar from "../container/navbar/Navbar";
export default {
    name: 'AdminOrderPage',
    components: {
        Navbar,
    },

    created: function() {
        this.getitems()
    },
    data() {
        return {
            allOrder: []
        }
    },

    methods: {
        getitems: function() {
            fetch('../enquiries.json')
                .then((response) => {
                    return response.json()
                })
                .then((result) => {
                    this.allOrder = result;
                    console.log(this.allOrder)
                })
                .catch(err => {
                    console.log(err);
                    cons
                });
        },
    }

}
</script>

<style lang="scss" scoped>
/*
bg = Background color
*/

/*
el = Element color
D = Dark
L = light
nr =  who position the color palette has in the style guide ( page 3 styleguide pdf "Color-deagram") 
*/

/* Fonts Importet form google font */

@import url('https://fonts.googleapis.com/css?family=Catamaran|PT+Sans|Quicksand|Raleway');
$font-Raleway: 'Raleway',
sans-serif;
$font-Catamaran: 'Catamaran',
sans-serif;
$font-Pt_sans: 'PT Sans',
sans-serif;
$font-Quicksand: 'Quicksand',
sans-serif;
/*Color*/

/*------------------*/

$bg-Color: #ffffff;
/*Blue Pallete nr.1*/

$el-L-ExstraLiteblue: #D7E2ED;
$el-L-Liteblue: #B6DBF2;
$el-L-Blue: #79ACD9;
$el-D-LiteDarkBlue: #416A8E;
$el-D-Darkblue: #323640;
/*Green Palette nr.2*/

$el-L-Green: #82BFBF;
$el-D-Green: #5E8A8A;
$el-D-ExstraliteGray: #BBBFBF;
$el-D-LiteDarkGray: #707373;
$el-D-DarkGray: #404141;
/*White pallette nr.3*/

$el-L-White: #FBFBFB;
$el-L-White2: #F6F6F6;
$el-L-White3: #FAFAFA;
$el-L-White4: #F0F0F0;
/*Exstra Color nr.4*/

$ek-D-Red: #B92025;
$ek-D-Blue: #17273F;
$ek-D-Gray: #E8E8E8;
.Card {
    background-color: $el-D-LiteDarkBlue;
    border-radius: 21px 21px 21px 21px;
    margin-left: auto;
    margin-right: auto;
    max-width: 1000px;
    height: 100%;
    margin-top: 35px;
    padding: 20px;
    &__hombutton {
        /* button back */
        margin-right: 10px;
        float: left;
        margin-bottom: 0px;
        margin-top: 10px;
    }
    &__heding {
        /* hedign card */
        text-align: center;
        padding-top: 15px;
        font-family: $font-Quicksand;
        font-weight: 100;
        color: $el-D-Darkblue;
        width: 50%;
        text-align: auto;
        margin: auto;
        &_hr {
            /* heding hr */
            border: 2px solid $el-L-Blue;
        }
        &-elemetn {
            margin-top: 45px;
            margin: auto;
            &__item {
                display: grid;
                grid-template-columns: 1fr 1fr;
                margin: 15px;
                background-color: $el-D-Darkblue;
                border-radius: 10px;
                padding: 60px;
                font-size: 30px;
                text-decoration: none !important;
                box-shadow: 0px 2px 5px 1px rgba(0, 0, 0, 0.24);
                &-1 {
                    /*  arrow */
                    margin: 10px;
                    -ms-transform: rotate(180deg);
                    /* IE 9 */
                    -webkit-transform: rotate(180deg);
                    /* Safari 3-8 */
                    transform: rotate(180deg);
                }
                &-2 {
                    /* name of enquerys */
                    margin: 15px;
                    text-align: right;
                    color: $el-L-White4;
                    font-family: $font-Catamaran;
                }
            }
        }
    }
}

@media screen and (max-width: 1050px) {
    /* show it on small screens */
    .Card {
        border-radius: 0px;
    }
}
</style>
 */