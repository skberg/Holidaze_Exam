<template>
    <div>
    
        <navbar></navbar>
    
    
    
    
        <div class="[ Card ]">
            <div class="[ Card__hombutton ]">
                <router-link to="/AdminOrderPage">
                    <img src="../../assets/Icons/LefBlue.svg" alt="hedicone" width="40">
                </router-link>
            </div>
            <div class="[ Card__heding ]">
                <h1>Orders-listing </h1>
                <hr class="[ Card__heding_hr ]">
            </div>
    
            <div class="[ holder ]">
                <div class="[ holder__userinfo ]" v-for="UserName in filteredArray">
                    <h3 class="[ holder__userinfo-heding ]">Order# {{ UserName.clientName }}</h3>
    
                    <hr>
    
                    <div class="[ holder__userinfo__Usercard ]">
                        <h1>Order infro</h1>
                        <hr class="[ hr ]">
                        <div class="[ holder__userinfo__Usercard-bg ]">
                            <div class="[ holder__userinfo__Usercard-item  ]">
    
                                <div>
                                    <h4 class="[ holder__userinfo__Usercard-item-heding  ]">Establishment:</h4>
                                    <hr class="[ holder__hr ]">
                                    <p class="[ holder__userinfo__Usercard-item-Cont ]">{{UserName.establishment}}</p>
                                </div>
    
    
                                <div>
                                    <h4 class="[ holder__userinfo__Usercard-item-heding  ]">Mail:</h4>
                                    <hr class="[ holder__hr ]">
                                    <p class="[ holder__userinfo__Usercard-item-Cont ]">{{UserName.email}}</p>
    
                                </div>
                            </div>
    
                            <div class="[ holder__userinfo__Usercard-item  ]">
    
                                <div>
                                    <h4 class="[ holder__userinfo__Usercard-item-heding  ]">Check in:</h4>
                                    <hr class="[ holder__hr ]">
                                    <p class="[ holder__userinfo__Usercard-item-Cont ]">{{UserName.checkin}}</p>
                                </div>
    
                                <div>
                                    <h4 class="[ holder__userinfo__Usercard-item-heding  ]">Check out:</h4>
                                    <hr class="[ holder__hr ]">
                                    <p class="[ holder__userinfo__Usercard-item-Cont ]">{{UserName.checkout}}</p>
    
                                </div>
                                <div>
                                    <h4 class="[ holder__userinfo__Usercard-item-heding  ]">Users Phone number:</h4>
                                    <hr class="[ holder__hr ]">
                                    <p class="[ holder__userinfo__Usercard-item-Cont ]">{{UserName.PhoneNr}}</p>
    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    
    
    
    
        </div>
    
        <div class="[ button ]" v-for="UserName in filteredArray">
    
            <a class="[  button__itemYes ]" :href="`mailto:${UserName.email}?subject=Hey ${UserName.clientName}&body= We are glad to welcome you to your stay at ${UserName.establishment}`">Approved</a>
            <a class="[  button__itemNo ]" :href="`mailto:${UserName.email}?subject=Hey ${UserName.clientName}&body= we are sorry but your stay at ${UserName.establishment} was not approved`">Not approved</a>
        </div>
    
    </div>
</template>

<script>
import Navbar from "../container/navbar/Navbar";
export default {

    name: 'AdminOrderListing',

    props: {
        name: {
            type: String,
        }
    },
    components: {
        Navbar,
    },

    data() {
        return {
            item: [],
            filteredArray: [],

        }
    },

    created() {
        this.getignData()
        console.log('this.$route.params.id', this.$route.params.clientName)
        // do you see this is now in the console?
        // so you going to do what you did on the previous page
    },
    methods: {
        getignData: function() {
            fetch('../enquiries.json')
                .then((response) => {
                    return response.json()
                })
                .then((result) => {
                    this.allitem = result;
                    this.filteredArray = result.filter((value) => {
                        return value.clientName === this.$route.params.clientName
                    })
                    console.log(this.filteredArray)

                })
                .catch(err => {
                    console.log(err);

                });
        },

        created: function() {

            var currentUrl = this.$route.query.page;

            console.log(this.currentUrl);

        }




    }
}
</script>








<style lang="scss" scoped>
/*
bg = Background color
*/

/*
el = Element color
D = Dark
L = light
nr =  who position the color palette has in the style guide ( page 3 styleguide pdf "Color-deagram") 
*/

/* Fonts Importet form google font */

@import url('https://fonts.googleapis.com/css?family=Catamaran|PT+Sans|Quicksand|Raleway');
$font-Raleway: 'Raleway',
sans-serif;
$font-Catamaran: 'Catamaran',
sans-serif;
$font-Pt_sans: 'PT Sans',
sans-serif;
$font-Quicksand: 'Quicksand',
sans-serif;
/*Color*/

/*------------------*/

$bg-Color: #ffffff;
/*Blue Pallete nr.1*/

$el-L-ExstraLiteblue: #D7E2ED;
$el-L-Liteblue: #B6DBF2;
$el-L-Blue: #79ACD9;
$el-D-LiteDarkBlue: #416A8E;
$el-D-Darkblue: #323640;
/*Green Palette nr.2*/

$el-L-Green: #82BFBF;
$el-D-Green: #5E8A8A;
$el-D-ExstraliteGray: #BBBFBF;
$el-D-LiteDarkGray: #707373;
$el-D-DarkGray: #404141;
/*White pallette nr.3*/

$el-L-White: #FBFBFB;
$el-L-White2: #F6F6F6;
$el-L-White3: #FAFAFA;
$el-L-White4: #F0F0F0;
/*Exstra Color nr.4*/

$ek-D-Red: #B92025;
$ek-D-Blue: #17273F;
$ek-D-Gray: #E8E8E8;
.Card {
    /* Blue card */
    background-color: $el-D-LiteDarkBlue;
    border-radius: 21px 21px 21px 21px;
    margin-left: auto;
    margin-right: auto;
    max-width: 1000px;
    margin-top: 35px;
    margin-bottom: 35px;
    padding: 20px;
    &__hombutton {
        /* button back */
        margin-left: 10px;
        margin-bottom: 0px;
        margin-top: 10px;
    }
    &__heding {
        /* hedign card */
        text-align: center;
        padding-bottom: 15px;
        padding-top: 0px;
        font-family: $font-Quicksand;
        font-weight: 100;
        color: $el-D-Darkblue;
        width: 50%;
        text-align: auto;
        margin: auto;
        &_hr {
            /* heding hr */
            border: 2px solid $el-L-Blue;
        }
    }
    .holder {
        /* holder all element */
        margin: 15px auto;
        width: auto;
        &__userinfo {
            background-color: $el-D-Darkblue;
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            margin: 15px auto;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0px 2px 5px 1px rgba(0, 0, 0, 0.185);
            &-heding {
                /* heding order */
                text-align: center;
                font-family: $font-Catamaran;
                font-weight: 900;
                color: $el-D-DarkGray;
                padding: 20px;
                margin: auto;
                font-size: 2rem;
                border-radius: 10px;
                background-color: $el-L-White4;
            }
            &__Usercard {
                h1 {
                    padding-left: 30px;
                    color: $ek-D-Gray;
                    font-family: $font-Catamaran;
                }
                &-bg {
                    /* element bg color and style  */
                    background-color: $ek-D-Gray;
                    margin: 5px;
                    border-radius: 10px;
                    padding: 10px;
                    border-radius: 10px;
                    width: auto;
                    height: auto;
                }
                &-item {
                    /* elemnt holder */
                    padding-left: 15px;
                    &-heding {
                        /* element heding  */
                        font-family: $font-Catamaran;
                        margin-bottom: 0px;
                        width: 50%;
                    }
                    &-Cont {
                        /* element */
                        margin-top: 0px;
                        padding-left: 10px;
                        font-family: $font-Pt_sans;
                    }
                }
            }
        }
        &__hr {
            /* element under line */
            border: 0.8px solid $el-L-Blue;
            border-radius: 10px;
            margin-top: 0px;
            width: 30%;
            margin-left: 1px;
        }
    }
}

hr {
    border: 2px solid $el-L-Blue;
    /* side line */
    border-radius: 10px;
}

.Router-style {
    text-decoration: none;
}

.button {
    display: grid;
    grid-template-columns: 1fr 1fr;
    margin: 10px auto;
    max-width: 400px;
    &__itemYes {
        text-decoration: none;
        background-color: $el-D-LiteDarkBlue;
        display: block;
        margin: 15px;
        width: 80%;
        border: none;
        padding: 10px;
        ;
        border-radius: 5px;
        color: $el-L-White;
        font-family: $font-Catamaran;
        font-weight: 700;
        font-size: 1rem;
        text-align: center;
    }
    &__itemNo {
        text-decoration: none;
        display: block;
        margin: 15px;
        width: 80%;
        border: none;
        padding: 10px;
        ;
        text-align: center;
        border-radius: 5px;
        background-color: $ek-D-Red;
        color: $el-L-White;
        font-family: $font-Catamaran;
        font-weight: 700;
        font-size: 1rem;
    }
}

@media screen and (max-width: 1050px) {
    /* show it on small screens */
    .Card {
        /* blue card  */
        border-radius: 0px;
        &__heding {
            /* card heding */
            text-align: center;
            padding-top: 15px;
            font-family: $font-Quicksand;
            width: 50%;
            text-align: auto;
            margin: auto;
            &_hr {
                /* card underline */
                margin-top: 0px;
                border: 1px solid $el-L-Blue;
                display: block;
            }
        }
        .holder {
            &__userinfo {
                /* making it responsive  */
                display: grid;
                grid-template-columns: 1fr;
                margin: 15px auto;
                padding: 15px;
                border-radius: 10px;
                box-shadow: 0px 2px 5px 1px rgba(0, 0, 0, 0.185);
                &-heding {
                    /* order# */
                    text-align: center;
                    font-family: $font-Catamaran;
                    font-weight: 900;
                    color: $el-D-DarkGray;
                    padding: 20px;
                    margin: auto;
                    font-size: 2rem;
                    border-radius: 10px;
                    background-color: $el-L-White4;
                }
                &__Usercard {
                    h1 {
                        /* heding */
                        display: none;
                    }
                    &-bg {
                        /* holder list  */
                        margin: auto;
                        border-radius: 10px;
                        padding: 0px;
                        width: auto;
                    }
                    background-color: $ek-D-Gray;
                    border-radius: 10px;
                    margin: 5px;
                    &-item {
                        /* item */
                        padding-left: 15px;
                        &-heding {
                            /* element heding */
                            font-family: $font-Catamaran;
                            margin-bottom: 0px;
                            width: 50%;
                        }
                        &-Cont {
                            /* element */
                            margin-top: 0px;
                            padding-left: 10px;
                        }
                    }
                }
            }
            &__hr {
                /* element under line */
                border: 0.8px solid $el-L-Blue;
                border-radius: 10px;
                margin-top: 0px;
                width: 30%;
                margin-left: 1px;
                display: block;
            }
        }
    }
}

.button {
      display: grid;
    grid-template-columns: 1fr;
}
hr {
    /* side line hidde */
    display: none;
}

@media screen and (min-width: 1050px) {
    hr {
        /* side line show */
        display: block;
    }
}
</style>

