<template>
    <div>
        <navbar></navbar>
    <div class="[ wrapper ]">
        <div class="[ wrapper__card ]">
            <div @submit.prevent="onLoginChlicked()" class="[ wrapper__card__login ]">
    
                <div class="[ wrapper__card__login__img ]">
                    <img src="../../assets/Icons/Dashbord.svg" alt="hedicone">
                </div>
    
                <input type="text" class="[ wrapper__card__login__input ]" placeholder="Username" v-model="username" v-bind:class="{ 'error-border': inputUsernameError  }" />
            <div class="[ alert ]" v-if="showUsernameError" role="alert">
                     <p class="[ alert-item ]">Please enter the correct username</p> 
                    </div>

                    <input type="password" class="[ wrapper__card__login__input ]" placeholder="Password" v-model="password" v-bind:class="{ 'error-border': inputPasswordError }" /> 

                    <div class="[ alert ]" v-if="showPasswordError" role="alert">
                        <p class="[ alert-item ]">Please enter the correct password</p> 
    
                    </div>
                </div>
               
            </div>
           <div class="[ buttone-outline ]">
                    <button class="button" v-on:click="onLoginChlicked()" type="submit">Login</button>
                </div>
        </div>
    </div>
</template>

<script>
import Navbar from "../container/navbar/Navbar";


export default {
    name: "AdminLoginpage",

    components: {
        Navbar,
    },
    props: {
        massage: String,
        showUsernameError: Boolean,
        showPasswordError: Boolean,
        inputUsernameError: Boolean,
        inputPasswordError: Boolean,
    },

    data() {
        return {
            username: "",
            password: "",
        }
    },

   methods: {
        onLoginChlicked() {
            const cachedUser = localStorage.getItem('username');
            const cachedPassword = localStorage.getItem('password');

            if (this.username !== cachedUser) {
                this.showUsernameError = true;
                this.inputUsernameError = true;
                this.message = 'Please enter the correct login details';
            } else if (this.password !== cachedPassword) {
                this.showUsernameError = false;
                this.inputUsernameError = false;
                this.showPasswordError = true;
                this.inputPasswordError = true;
                this.message = 'Please enter the correct login details';
            } else {
                this.$router.push("AdminPanelpage");
            }

        }
    },


}
</script>

<style lang="scss" scoped>
/*
bg = Background color
*/

/*
el = Element color
D = Dark
L = light
nr =  who position the color palette has in the style guide ( page 3 styleguide pdf "Color-deagram") 
*/

/* Fonts Importet form google font */

@import url('https://fonts.googleapis.com/css?family=Catamaran|PT+Sans|Quicksand|Raleway');
$font-Raleway: 'Raleway',
sans-serif;
$font-Catamaran: 'Catamaran',
sans-serif;
$font-Pt_sans: 'PT Sans',
sans-serif;
$font-Quicksand: 'Quicksand',
sans-serif;



/*Color*/

/*------------------*/
$bg-Color: #ffffff;


/*Blue Pallete nr.1*/
$el-L-ExstraLiteblue: #D7E2ED;
$el-L-Liteblue: #B6DBF2;
$el-L-Blue: #79ACD9;
$el-D-LiteDarkBlue: #416A8E;
$el-D-Darkblue: #323640;

/*Green Palette nr.2*/
$el-L-Green: #82BFBF;
$el-D-Green: #5E8A8A;
$el-D-ExstraliteGray: #BBBFBF;
$el-D-LiteDarkGray: #707373;
$el-D-DarkGray: #404141;




/*White pallette nr.3*/
$el-L-White: #FBFBFB;
$el-L-White2: #F6F6F6;
$el-L-White3: #FAFAFA;
$el-L-White4: #F0F0F0;



/*Exstra Color nr.4*/
$ek-D-Red: #B92025;
$ek-D-Blue: #17273F;
$ek-D-Gray: #E8E8E8;

body {
    background-color: $bg-Color;
}

.wrapper {
    display: grid;
    place-content: center;


&__card {
    margin-top: 125px;
    width: 490px;
    height: 490px;
    border-radius: 20px;
    padding: 25px;
    background-color: $el-L-White3;
    box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 29%);
    &__login {
        text-align: center;
        &__img {
         box-shadow: 0px 2px 1px 0px rgba(0, 0, 0, 19%);
        
        
            width: 100px;
            height: 100px;
            margin-top: 25px;
            margin: auto;
            border-radius: 90%;
        }
        &__input {
            display: block;
            margin-left: auto;
            margin-right: auto;
            margin-top: 80px;
            min-height: 30px;
            background-color: transparent;
             border-top:transparent;
             border-left: transparent;
             border-right: transparent;
            border-bottom-color: $el-D-Green;
            width:80%;
           
            

    
          
        }
     
    }
}
}

 .alert{
            
            
            font-weight: 700;
            font-size: 0.7rem;
            width: 70%;
            height: 30px;
            border-radius: 10px;
            margin: auto;
            animation: mymove 0.5s;
          
            &-item{
                padding: 10px;
                background-color: $el-L-Green;
                color: $el-D-DarkGray;
                border-radius: 10px;
                font-family: $font-Catamaran;;
            }
        }

@keyframes mymove {
  from {height: 0px;}
  to {height: 30px;}
}
     
.buttone-outline{
display: flex;
    margin:  auto;
    width: 100%;

    left: 0;
    .button {
     margin:  auto;

   
      background-color: $el-D-LiteDarkBlue;
            color: $el-L-White;
            font-family: $font-Catamaran;
            font-weight: 800;
            border: none;
        
            
           border-radius: 0px 0px 20px 20px;
           padding: 10px;
            width: 100%;
            font-size: 18px;
            max-width: 350px;;
            text-align: center;
 
    }

}
.error-border{
      border-bottom-color: $ek-D-Red !important;;
    

   
}
@media screen and (max-width: 1050px) {
.wrapper {
  
 
    place-content: center;


&__card {
    margin-top: 0px;
    width: auto;
 
    height: auto;
    margin-top: 25px;

    border-radius: 10px 10px 0px 0px;
    padding: 75px;;
    
    background-color: $el-L-White3;
    box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 29%);
    &__login {
        text-align: center;
        width: 100%;
        &__img {
          
    
        }
        &__input {
            display: block;

            background-color: transparent;
             border-top:transparent;
             border-left: transparent;
             border-right: transparent;
            border-bottom-color: $el-D-Green;
            width: 100%;
           
            

    
          
        }
     
    }
}
}


.buttone-outline{
display: flex;
    margin:  auto;
    width: 100%;

    left: 0;
    .button {
     margin:  auto;

   
      background-color: $el-D-LiteDarkBlue;
            color: $el-L-White;
            font-family: $font-Catamaran;
            font-weight: 800;
            border: none;
        
            
           border-radius: 0px 0px 10px 10px;
           padding: 10px;
            width: 100%;
            font-size: 18px;
            max-width: 360px;;
            text-align: center;
 
    }

}




}

</style>

