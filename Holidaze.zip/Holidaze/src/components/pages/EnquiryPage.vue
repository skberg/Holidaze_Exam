<template>
    <div>
        <navbar></navbar>
        <div class="[ card ]">
    
    
    
    
            <form method="POST" action="http://192.168.64.2/Holidaze/server/enquiry-success.php" @submit="checkForm" >
    

                <div class="[ card-form-top ]">
                    <h5>step 1:</h5>
                    <label class="[ card-form-top__label ]" for="establishment">Establishment</label>
                    <input class="[ card-form-top__Input ]" type="text"  name="establishment" v-for="hotel in filteredArray" :value="hotel.establishmentName" id="establishment"readonly>
                      
                </div>
    

                <div class="[ card-form-error ]">
                    <p v-if="errors.length">
                        <p class="error" v-for="error in errors">{{ error }}</p>
                    </p>
                </div>
    
    
                <div class="[ card-form ]">
                    <h5>step 2:</h5>
    
                    <input class="[ card-form__Input ]" type="text" placeholder="Full name" name="clientName" id="clientName" v-model="name">
    
                    <input class="[ card-form__Input ]" type="text" placeholder="Email Address" name="email" id="email" v-model="mail">

                     
                    <input class="[ card-form__Input ]" type="Number" placeholder="Phone number" name="PhoneNr" id="PhoneNr" v-model="phone">
                </div>
    
    
                <div class="[ card-form-button ]">
                    <h5>step 3:</h5>
                    <label class="[ card-form-button__label ]" for="checkin">Check-in</label>
                    <input class="[ card-form-button__Input ]" type="date" name="checkin" id="checkin">
                    <label class="[ card-form-button__label ]" for="checkout">Check-out</label>
                    <input class="[ card-form-button__Input ]" type="date" name="checkout" id="checkout">
                </div>
                
   



                <input class="[ card-button ]" type="submit">
            </form>
        </div>
  
    </div>
</template>

<script>

import Navbar from "../container/navbar/Navbar";
import HomePage from "./HomePage"
export default {
    name: 'EnquiryPage',

    components: {
        Navbar,
        HomePage,
      

    },


    data() {
        return {
            allitem: [],
            sef: [],
            filteredArray: [],
            stordata:'',
            errors: [],
            name: null,
            mail: null,
            hotel:'',

        }
    },



      created() {
        this.getignData()
        console.log('this.$route.params.id', this.$route.params.id)
        // do you see this is now in the console?
        // so you going to do what you did on the previous page
        this.myFunction()
    },

    methods: {
           getignData: function() {
            fetch('../establishments.json')
                .then((response) => {
                    return response.json()
                })
                .then((result) => {
                    this.allitem = result;
                    this.filteredArray = result.filter((value) => {
                        return value.id === this.$route.params.id
              
                    })
                    console.log(this.filteredArray) 

                })
                .catch(err => {
                    console.log(err);

                });
        },

        checkForm: function(e) {

            if (this.name && this.mail && this.phone) return true;
            this.errors = [];

            if (!this.name) this.errors.push("Name required.");
            if (!this.mail) this.errors.push("E-mail required.");
             if (!this.phone) this.errors.push("Phone number required.");
            e.preventDefault();
        },

            myFunction:function() {
                
                    
     },

                
                
                
                
                
    }

}
</script>

<style lang="scss" scoped>
/*
bg = Background color
*/

/*
el = Element color
D = Dark
L = light
nr =  who position the color palette has in the style guide ( page 3 styleguide pdf "Color-deagram") 
*/

/* Fonts Importet form google font */

@import url('https://fonts.googleapis.com/css?family=Catamaran|PT+Sans|Quicksand|Raleway');
$font-Raleway: 'Raleway',
sans-serif;
$font-Catamaran: 'Catamaran',
sans-serif;
$font-Pt_sans: 'PT Sans',
sans-serif;
$font-Quicksand: 'Quicksand',
sans-serif;
/*Color*/

/*------------------*/

$bg-Color: #ffffff;
/*Blue Pallete nr.1*/

$el-L-ExstraLiteblue: #D7E2ED;
$el-L-Liteblue: #B6DBF2;
$el-L-Blue: #79ACD9;
$el-D-LiteDarkBlue: #416A8E;
$el-D-Darkblue: #323640;
/*Green Palette nr.2*/

$el-L-Green: #82BFBF;
$el-D-Green: #5E8A8A;
$el-D-ExstraliteGray: #BBBFBF;
$el-D-LiteDarkGray: #707373;
$el-D-DarkGray: #404141;
/*White pallette nr.3*/

$el-L-White: #FBFBFB;
$el-L-White2: #F6F6F6;
$el-L-White3: #FAFAFA;
$el-L-White4: #F0F0F0;
/*Exstra Color nr.4*/

$ek-D-Red: #B92025;
$ek-D-Blue: #17273F;
$ek-D-Gray: #E8E8E8;
.card {
    &-button {
        background-color: $el-D-LiteDarkBlue;
        margin: 15px auto;
        width: 75%;
        max-width: 500px;
        display: block;
        margin-left: auto;
        margin-right: auto;
        justify-content: center;
        text-decoration: none;
        text-align: center;
        padding: 10px;
        color: $el-L-White;
        border-radius: 5px;
        font-family: $font-Catamaran;
        font-weight: 700;
        font-size: 20px;
        border: none;
    }
    &-form {
        margin: auto;
        max-width: 800px;
        border-radius: 10px;
        padding: 15px;
        justify-content: center;
        background-color: $el-L-White3;
        display: grid;
        grid-template-columns: 1fr;
        box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 29%);

        h5{
              font-family: $font-Catamaran;
                font-size: 1.5em;
                    padding-bottom: 0px;
                    padding-left: 10px;
        }
        &-top {
            margin: 25px auto;
        max-width: 800px;
        border-radius: 10px;
        padding: 15px;
        justify-content: center;
        background-color: $el-L-White3;
        display: grid;
        grid-template-columns: 1fr;
        box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 29%);
            h5 {
                font-size: 1.5em;
                padding-bottom: 0px;
                padding-left: 10px;
                
            }
            &__label {
                margin: 10px;
                font-size: 1.1rem;
                font-family: $font-Catamaran;
                font-weight: 700;
                padding-left: 10px;
            }
            &__Input {
                width: 75%;
                margin: 10px auto;
                font-size: 1.1em;
                border-top: transparent;
                border-left: transparent;
                border-right: transparent;
                     font-family: $font-Pt_sans;
                border-bottom: $el-L-Green 2px solid;
                background-color: transparent;
                color: black;
            }
        }

 
        &-button {
            margin: 25px auto;
            max-width: 800px;
            border-radius: 10px;
            padding: 15px;
            justify-content: center;
            background-color: $el-L-White3;
            display: grid;
            grid-template-columns: 1fr;
            box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 29%);

            &__label {
                margin: 10px;
                font-size: 1.1rem;
                font-family: $font-Catamaran;
                font-weight: 700;
                padding-left: 10px;
                
            }
            &__Input {
                width: 75%;
                margin: 10px auto;
                font-size: 1.1em;
                border-top: transparent;
                border-left: transparent;
                border-right: transparent;
                font-family: $font-Pt_sans;
                border-bottom: $el-L-Green 2px solid;
                background-color: transparent;
                color: black;
            }
            h5 {    
              font-family: $font-Catamaran;
              font-size: 1.5em;
              padding-bottom: 0px;
              padding-left: 10px;
        }
    }
         



/*the center element*/

        &-error {
            background-color: $el-L-Green;
            color: $el-D-DarkGray;
            font-weight: 700;
            text-align: center;
            margin: auto;
      
            margin-bottom: 0px;
            max-width: 800px;
            padding: 0px;
            padding-top: 10px;
            padding-bottom: 1px;
            border-radius: 10px 10px 0px 0px;
          
        }
             &__label {
                margin: 10px;
                font-family: $font-Catamaran;
                font-weight: 100;
                padding-left: 10px;
                
            }
            &__Input {
                width: 75%;
                margin: 10px auto;
                font-size: 1.1em;
                border-top: transparent;
                border-left: transparent;
                border-right: transparent;
                   font-family: $font-Pt_sans;
                border-bottom: $el-L-Green 2px solid;
                background-color: transparent;
                color: black;
            }
                  h5 {
                    font-size: 1.5em;
                    padding-bottom: 0px;
                    padding-left: 10px;
                    
                }

    }
}




@media screen and (max-width: 1050px) {
    .card {
          &-form {
                border-radius: 0px;  
            &-top {
                border-radius: 0px;
            }
            &-button {
                border-radius: 0px;
            }


        &__Input {
            display: block;
            margin: 10px auto;
            font-size: 1.1em;
            width: 100%;
            border-top: transparent;
            border-left: transparent;
            border-right: transparent;
            border-bottom: $el-L-Green 2px solid;
            background-color: transparent;
            color: black;
        }

         &-error {
             border-radius: 0px;
             width: auto;;
         }
    
    }
    }
}
</style>
