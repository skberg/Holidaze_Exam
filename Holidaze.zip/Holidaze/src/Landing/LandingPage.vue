<template>
    <div class="Main">
        <navbar></navbar>

           <p v-if="errors.length">
                   
                        <p class="error-one" v-for="error in errors">{{ error }}</p>
                    </p>
        <div class="[ container ]">
    
                  
                          <p v-if="errors.length">
                        <p class="error-to" v-for="error in errors">{{ error }}</p>
                    </p>

 
         
    
            <div class="[ element ]" @submit="CardcPage">
    
                <!-- surch input -->
                <img class="[ element-img ]" src="../assets/Icons/lgoo.svg" alt="" width="250px">
                <h3 class="[ element-qout ]">Make the dream come true</h3>
    
    
                <div class="[ element__border-search ]">
                  <input type="search" name="Search-bar"  list="languages"  v-model="inputValue" placeholder="USA..." class="[ element__border-search__serch-bare ]"/>
                   
                   
               <datalist id="languages">
                <option v-for="item in items">{{item.contryChosing}} </option>
                
            </datalist>
                   
                </div>
                   
                <!-- surch input -->
    





      <!--  <router-link to="ResultPage">-->
      


            <div class="[ button__holder ]">
                
                <button class="[ button__holder__item ]" type="submit"  v-on:click="CardcPage" >Let's us take a look</button>
            
            </div>
            <!--Button to send user to the nest page -->
    
    
            </div>
    
    
    
    
          
        </div>
    
    
    
    
    
    
    
    </div>
</template>

<script>
import Navbar from "../components/container/navbar/Navbar";

export default {
    name: "LandingPage",

    created() {
        this.getitems();

    },
    components: {
        Navbar,
    },
    data() {
        return {
            search: '',
            inputValue: '',
            item:[],
            errors:[],
            name:null,
            items:[],
        }
    },



methods: {
    getitems: function() {
        fetch('establishments.json')
            .then((response) => {
                return response.json()
            })
            .then((result) => {
                this.items = result;
            })
            .catch(err => {
                console.log(err);
            });
    },
    filterByCountry(SearchQuery){
            console.log('SearchQuery', SearchQuery)
            if(this.items.length !== 0){
                this.filteredItems = this.items.filter((value) => {
                    return value.contryChosing === SearchQuery;
                  
                })
            }
            else{
                console.log('No data')
            }

    },




        CardcPage: function(e) {
       
            localStorage.setItem('SearchQuery', this.inputValue) /* i change the One ( that is the value in then input above) to this.input i get an undefind in the local sorage */

            if (this.inputValue == false) {
                this.errors = [];
                this.errors.push("You need to enter a country to continue");
            } else {
                this.$router.push({ name: 'ResultPage' });
            }

  
            e.preventDefault();


        },
         

    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
/*
bg = Background color
*/

/*
el = Element color
D = Dark
L = light
nr =  who position the color palette has in the style guide ( page 3 styleguide pdf "Color-deagram") 
*/

/* Fonts Importet form google font */

@import url('https://fonts.googleapis.com/css?family=Catamaran|PT+Sans|Quicksand|Raleway');
$font-Raleway: 'Raleway',
sans-serif;
$font-Catamaran: 'Catamaran',
sans-serif;
$font-Pt_sans: 'PT Sans',
sans-serif;
$font-Quicksand: 'Quicksand',
sans-serif;
/*Color*/

/*------------------*/

$bg-Color: #ffffff;
/*Blue Pallete nr.1*/

$el-L-ExstraLiteblue: #D7E2ED;
$el-L-Liteblue: #B6DBF2;
$el-L-Blue: #79ACD9;
$el-D-LiteDarkBlue: #416A8E;
$el-D-Darkblue: #323640;
/*Green Palette nr.2*/

$el-L-Green: #82BFBF;
$el-D-Green: #5E8A8A;
$el-D-ExstraliteGray: #BBBFBF;
$el-D-LiteDarkGray: #707373;
$el-D-DarkGray: #404141;
/*White pallette nr.3*/

$el-L-White: #FBFBFB;
$el-L-White2: #F6F6F6;
$el-L-White3: #FAFAFA;
$el-L-White4: #F0F0F0;
/*Exstra Color nr.4*/

$ek-D-Red: #B92025;
$ek-D-Blue: #17273F;
$ek-D-Gray: #E8E8E8;
.Main {
    background-image: url('../assets/img/IMg.png');
    background-repeat: no-repeat;
    background-position: center center;
    background-attachment: fixed;
    background-size: cover;
    height: 100vh;
    padding: 0;
    margin: 0;
}


.error-one {
    background-color: $el-L-Green;
    color: $el-D-DarkGray;
    font-weight: 700;
    text-align: center;
    margin: auto;
    width: 400px;
	height: 100px;
	position: absolute;
	top: -600px;
	bottom: 0;
	left: 0;
	right: 0;
	padding-top: 20px;
	margin: auto;
    border-radius: 10px 10px 0px 0px;
    animation: mymove 0.5s ;
}


@keyframes mymove {
  from {height: 0px;}
  to {height: 100px;}
}
.error-to {
 margin: auto;
    text-align: center;
    background-color: $el-L-Green;
    color: $el-D-DarkGray;
    margin: 5px;
    padding: 7px;
    border-radius: 2px ;
    
}



.element {
    
    &-img {
        display: block;
        justify-content: center;
        margin: 0px auto;
        margin-top: 25px;
    }
    &-qout {
        text-align: center;
        color: $el-L-Green;
        margin-top: 25px;
        margin-bottom: 35px;
        font-family: $font-Raleway;
    }
    &-Button{
        display: block;
        margin: 55px auto;
    }
    &__border-search {
        border: 1px solid $el-D-LiteDarkBlue;
        padding: 5px;
        border-radius: 5px;
        margin-top: 5px;
        &__serch-bare {
            width: 100%;
            font-size: 1rem;
            border: none;
            height: 30px;
        }
    }


     .button__holder {
         display: block;
         margin-top: 55px;
        &__item {
            padding: 5px;
            width: 50%;
            margin:auto;
             display:block;
            background-color: #416A8E;
            border-radius: 5px;
            color: $el-L-White;
            font-family: $font-Catamaran;
            font-style: bold;
            border: none;
            font-size: 15px
        }
    }
}





  
@media (min-width: 50px)  {
  
.element {
    
    &-img {
        display: block;
        justify-content: center;
        margin: 10px auto;
        width: auto;
        max-width: 280px;;
        margin-top: 25px;
        
    }
 


   
}

  
.error-one {
   display: none;
}
  
  .error-to{
      display: block;
  }
}
@media screen and (min-width: 490px) {


  
.error-one {
   display: block;
}
  
  .error-to{
      display: none;
  }
}






</style>
