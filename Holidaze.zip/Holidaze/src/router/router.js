import Vue from 'vue';
import VueRouter from 'vue-router';
import AdminCreatHPage from '../components/pages/AdminCreatHPage';
import Adminpagelogin from '../components/pages/AdminLoginpage';
import AdminOrderPage from '../components/pages/AdminOrderPage';
import AdminPanelpage from '../components/pages/AdminPanelpage';
import ContatusPage from '../components/pages/ContatusPage';
import HomePage from '../components/pages/HomePage';
import LandingPage from '../Landing/LandingPage';
import ResultPage from '../components/pages/ResultSurch';
import EnquiryPage from '../components/pages/EnquiryPage';
import AdminOrderListing from '../components/pages/AdminOrderListing';







Vue.use(VueRouter)





const router = new VueRouter({
    mode: 'history',    /* to remove the hash */ 
    routes:[
        {
            path: '/',
            name: 'LandingPage',
            component: LandingPage,
        },
        {
            path: '/ContatusPage',
            name: 'ContatusPage',
            component: ContatusPage,
        },
        {
            path: '/HomePage/:id',
            name:  'HomePage',
            component: HomePage,
        },
        {
            path: '/EnquiryPage/:id',
            name: 'EnquiryPage',
            component: EnquiryPage,
        },

        {
            path:'/Adminpagelogin',
            name:'Adminpagelogin',
            component: Adminpagelogin,
        },
        {
            path:'/AdminPanelpage',
            name: 'AdminPanelpage',
            component: AdminPanelpage,
        },
        {
            path:'/AdminOrderPage',
            name:'AdminOrderPage',
            component: AdminOrderPage,
        },
        {
            path:'/AdminOrderListing/:clientName',
            name:'AdminOrderListing',
            component: AdminOrderListing,
         
        },
        {
            path: '/AdminCreatHPage',
            name: 'AdminCreatHPage',
            component: AdminCreatHPage,
        },
      
        
     
        {
            path: '/ResultPage',
            name: 'ResultPage',
            component: ResultPage
        }
    ]
})
export default router;