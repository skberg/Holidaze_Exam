<template>

  <router-view></router-view>

</template>

<script>
(function () {
        localStorage.setItem('username', '--');
        localStorage.setItem('password', '--');
    })();

export default {
  name: 'app',
  components: {
   
  }
}
</script>

<style lang="scss" >
/*
bg = Background color
*/

/*
el = Element color
D = Dark
L = light
nr =  who position the color palette has in the style guide ( page 3 styleguide pdf "Color-deagram") 
*/

/* Fonts Importet form google font */

@import url('https://fonts.googleapis.com/css?family=Catamaran|PT+Sans|Quicksand|Raleway');
$font-Raleway: 'Raleway',
sans-serif;
$font-Catamaran: 'Catamaran',
sans-serif;
$font-Pt_sans: 'PT Sans',
sans-serif;
$font-Quicksand: 'Quicksand',
sans-serif;



/*Color*/

/*------------------*/
$bg-Color: #ffffff;


/*Blue Pallete nr.1*/
$el-L-ExstraLiteblue: #D7E2ED;
$el-L-Liteblue: #B6DBF2;
$el-L-Blue: #79ACD9;
$el-D-LiteDarkBlue: #416A8E;
$el-D-Darkblue: #323640;

/*Green Palette nr.2*/
$el-L-Green: #82BFBF;
$el-D-Green: #5E8A8A;
$el-D-ExstraliteGray: #BBBFBF;
$el-D-LiteDarkGray: #707373;
$el-D-DarkGray: #404141;




/*White pallette nr.3*/
$el-L-White: #FBFBFB;
$el-L-White2: #F6F6F6;
$el-L-White3: #FAFAFA;
$el-L-White4: #F0F0F0;



/*Exstra Color nr.4*/
$ek-D-Red: #B92025;
$ek-D-Blue: #17273F;
$ek-D-Gray: #E8E8E8;

body {
    padding:0;
    margin:0;
   
    background-color: $bg-Color;

}

.container{
  position: absolute;
  margin: auto;
  top: 59px;
  right: 0;
  bottom: 0;
  left: 0;
  width: 390px;
  height: 590px;
  border-radius: 10px;
  padding: 35px;
 
  background-color: $el-L-White3; 
  
   box-shadow: 0px 2px 3px 0px rgba(0, 0, 0, 29%);

    
    }
   

@media screen and (max-width: 414px) {
    .container{
    position: relative;

      width: auto;
      height: 100vh;
      margin-top: -20px;
      border-radius: 0px;
       top: 0px;

    }
}

</style>
